<?php
namespace Rest_Api\Models;

use App\Models\Crud_model; //access main app's models

	class Api_Model extends Crud_model {
		//your methods
	}

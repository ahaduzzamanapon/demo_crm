<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["google_docs_integration"] = "Integração com Planilhas Google";
$lang["google_docs"] = "Planilhas Google";
$lang["google_docs_integration_integrate_google_docs"] = "Integrar Planilhas Google";
$lang["google_docs_integration_client_can_access_google_docs"] = "O cliente pode acessar o Planilhas Google?";
$lang["google_docs_integration_add_document"] = "Adicionar planilha";
$lang["google_docs_integration_edit_document"] = "Editar planilha";
$lang["google_docs_integration_delete_document"] = "Excluir planilha";
$lang["google_docs_integration_all_client_contacts"] = "Todos os contatos do cliente";
$lang["google_docs_integration_choose_client_contacts"] = "Escolha os contatos do cliente";

$lang["google_docs_integration_can_manage_google_docs"] = "É possível gerenciar o Planilhas Google?";

return $lang;

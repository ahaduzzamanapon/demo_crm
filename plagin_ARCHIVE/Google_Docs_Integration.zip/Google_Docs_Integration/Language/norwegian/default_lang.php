<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["google_docs_integration"] = "Google Docs-integrering";
$lang["google_docs"] = "Google Regneark";
$lang["google_docs_integration_integrate_google_docs"] = "Integrer Google Docs";
$lang["google_docs_integration_client_can_access_google_docs"] = "Klienten har tilgang til Google Docs?";
$lang["google_docs_integration_add_document"] = "Legg til regneark";
$lang["google_docs_integration_edit_document"] = "Rediger regneark";
$lang["google_docs_integration_delete_document"] = "Slett regneark";
$lang["google_docs_integration_all_client_contacts"] = "Alle klientkontakter";
$lang["google_docs_integration_choose_client_contacts"] = "Velg klientkontakter";

$lang["google_docs_integration_can_manage_google_docs"] = "Kan administrere Google Docs?";

return $lang;

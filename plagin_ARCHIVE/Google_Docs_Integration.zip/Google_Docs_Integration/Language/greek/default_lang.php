<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["google_docs_integration"] = "Integrazione di Fogli Google";
$lang["google_docs"] = "Fogli Google";
$lang["google_docs_integration_integrate_google_docs"] = "Integra Fogli Google";
$lang["google_docs_integration_client_can_access_google_docs"] = "Il cliente può accedere a Fogli Google?";
$lang["google_docs_integration_add_document"] = "Aggiungi foglio di calcolo";
$lang["google_docs_integration_edit_document"] = "Modifica foglio di calcolo";
$lang["google_docs_integration_delete_document"] = "Elimina foglio di calcolo";
$lang["google_docs_integration_all_client_contacts"] = "Tutti i contatti del cliente";
$lang["google_docs_integration_choose_client_contacts"] = "Scegli i contatti del cliente";

$lang["google_docs_integration_can_manage_google_docs"] = "Può gestire Fogli Google?";

return $lang;

<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["google_docs_integration"] = "Google Docs-integratie";
$lang["google_docs"] = "Google Docs";
$lang["google_docs_integration_integrate_google_docs"] = "Google Docs integreren";
$lang["google_docs_integration_client_can_access_google_docs"] = "Klant heeft toegang tot Google Docs?";
$lang["google_docs_integration_add_document"] = "Document toevoegen";
$lang["google_docs_integration_edit_document"] = "Document bewerken";
$lang["google_docs_integration_delete_document"] = "Verwijder document";
$lang["google_docs_integration_all_client_contacts"] = "Alle klantcontacten";
$lang["google_docs_integration_choose_client_contacts"] = "Kies klantcontacten";

$lang["google_docs_integration_can_manage_google_docs"] = "Kan Google Docs beheren?";

return $lang;

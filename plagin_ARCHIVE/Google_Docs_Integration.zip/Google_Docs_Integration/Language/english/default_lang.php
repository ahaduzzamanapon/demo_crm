<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["google_docs_integration"] = "Google Docs Integration";
$lang["google_docs"] = "Google Docs";
$lang["google_docs_integration_integrate_google_docs"] = "Integrate Google Docs";
$lang["google_docs_integration_client_can_access_google_docs"] = "Client can access Google Docs?";
$lang["google_docs_integration_add_document"] = "Add document";
$lang["google_docs_integration_edit_document"] = "Edit document";
$lang["google_docs_integration_delete_document"] = "Delete document";
$lang["google_docs_integration_all_client_contacts"] = "All client contacts";
$lang["google_docs_integration_choose_client_contacts"] = "Choose client contacts";

$lang["google_docs_integration_can_manage_google_docs"] = "Can manage Google Docs?";

return $lang;

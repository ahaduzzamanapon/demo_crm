<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["google_docs_integration"] = "Integrace Tabulek Google";
$lang["google_docs"] = "Tabulky Google";
$lang["google_docs_integration_integrate_google_docs"] = "Integrovat Tabulky Google";
$lang["google_docs_integration_client_can_access_google_docs"] = "Klient má přístup k Tabulkám Google?";
$lang["google_docs_integration_add_document"] = "Přidat tabulku";
$lang["google_docs_integration_edit_document"] = "Upravit tabulku";
$lang["google_docs_integration_delete_document"] = "Smazat tabulku";
$lang["google_docs_integration_all_client_contacts"] = "Všechny klientské kontakty";
$lang["google_docs_integration_choose_client_contacts"] = "Vyberte kontakty klienta";

$lang["google_docs_integration_can_manage_google_docs"] = "Umíte spravovat Tabulky Google?";

return $lang;

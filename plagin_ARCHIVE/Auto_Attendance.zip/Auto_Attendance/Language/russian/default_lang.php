<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["auto_attendance"] = "Автоматическое посещение";
$lang["auto_attendance_auto_clock_in_on_signin"] = "Автоматическое подключение часов при входе в систему";
$lang["auto_attendance_auto_clock_out_on_signout"] = "Автоматическое отключение при выходе";
$lang["auto_attendance_auto_clock_out_after"] = "Автоматическое отключение после";

return $lang;

<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["auto_attendance"] = "Automatische aanwezigheid";
$lang["auto_attendance_auto_clock_in_on_signin"] = "Automatisch inklokken bij inloggen";
$lang["auto_attendance_auto_clock_out_on_signout"] = "Automatisch uitklokken bij afmelden";
$lang["auto_attendance_auto_clock_out_after"] = "Automatisch uitklokken na";

return $lang;

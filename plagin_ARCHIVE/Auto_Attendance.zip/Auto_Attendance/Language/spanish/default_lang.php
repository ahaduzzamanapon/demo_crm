<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["auto_attendance"] = "Asistencia automática";
$lang["auto_attendance_auto_clock_in_on_signin"] = "Reloj automático al iniciar sesión";
$lang["auto_attendance_auto_clock_out_on_signout"] = "Salida automática al cerrar sesión";
$lang["auto_attendance_auto_clock_out_after"] = "Salida automática después de";

return $lang;

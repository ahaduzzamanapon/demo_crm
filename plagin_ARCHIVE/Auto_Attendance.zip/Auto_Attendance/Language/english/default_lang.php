<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["auto_attendance"] = "Auto Attendance";
$lang["auto_attendance_auto_clock_in_on_signin"] = "Auto clock in on sign in";
$lang["auto_attendance_auto_clock_out_on_signout"] = "Auto clock out on sign out";
$lang["auto_attendance_auto_clock_out_after"] = "Auto clock out after";

return $lang;

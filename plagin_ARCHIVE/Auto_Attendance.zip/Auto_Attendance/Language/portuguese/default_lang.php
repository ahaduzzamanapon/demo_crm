<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["auto_attendance"] = "Atendimento automático";
$lang["auto_attendance_auto_clock_in_on_signin"] = "Cronograma automático ao fazer login";
$lang["auto_attendance_auto_clock_out_on_signout"] = "Relógio automático ao sair";
$lang["auto_attendance_auto_clock_out_after"] = "Relógio automático após";

return $lang;

<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["auto_attendance"] = "Αυτόματη Συμμετοχή";
$lang["auto_attendance_auto_clock_in_on_signin"] = "Αυτόματο ρολόι κατά την είσοδο";
$lang["auto_attendance_auto_clock_out_on_signout"] = "Αυτόματο ρολόι κατά την αποσύνδεση";
$lang["auto_attendance_auto_clock_out_after"] = "Αυτόματο ρολόι μετά";

return $lang;

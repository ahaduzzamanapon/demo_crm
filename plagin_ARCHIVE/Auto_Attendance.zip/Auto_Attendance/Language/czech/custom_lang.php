<?php //copy from default_lang.php file and update

$lang["auto_attendance_example"] = "Example";

return $lang;
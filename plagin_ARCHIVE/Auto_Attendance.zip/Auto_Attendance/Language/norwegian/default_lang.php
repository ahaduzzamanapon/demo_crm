<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["auto_attendance"] = "Automatisk oppmøte";
$lang["auto_attendance_auto_clock_in_on_signin"] = "Automatisk klokke inn ved pålogging";
$lang["auto_attendance_auto_clock_out_on_signout"] = "Automatisk klokke ut ved avlogging";
$lang["auto_attendance_auto_clock_out_after"] = "Automatisk klokke ut etter";

return $lang;

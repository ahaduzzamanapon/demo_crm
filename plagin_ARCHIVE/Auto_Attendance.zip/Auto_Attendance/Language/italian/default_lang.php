<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["auto_attendance"] = "Presenza automatica";
$lang["auto_attendance_auto_clock_in_on_signin"] = "Accedi automaticamente all'accesso";
$lang["auto_attendance_auto_clock_out_on_signout"] = "Spegnimento automatico alla disconnessione";
$lang["auto_attendance_auto_clock_out_after"] = "Spegnimento automatico dopo";

return $lang;

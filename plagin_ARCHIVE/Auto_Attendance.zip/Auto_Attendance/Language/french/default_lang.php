<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["auto_attendance"] = "Présence automatique";
$lang["auto_attendance_auto_clock_in_on_signin"] = "Pointage automatique à la connexion";
$lang["auto_attendance_auto_clock_out_on_signout"] = "Pointage automatique à la déconnexion";
$lang["auto_attendance_auto_clock_out_after"] = "Départ automatique après";

return $lang;

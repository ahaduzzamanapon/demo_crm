<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["google_meet_integration"] = "Integrace Google Meet";
$lang["google_meet_integration_meetings"] = "Schůzky";
$lang["google_meet_integration_topic"] = "Téma";
$lang["google_meet_meetings"] = "Schůzky Google Meet";
$lang["google_meet"] = "Google Meet";
$lang["google_meet_integration_join_meeting"] = "Připojit se ke schůzce";
$lang["google_meet_integration_other_settings"] = "Další nastavení";
$lang["google_meet_integration_integrate_google_meet"] = "Integrovat Google Meet";
$lang["google_meet_integration_who_can_manage_meetings"] = "Kdo může spravovat schůzky";
$lang["google_meet_integration_users_help_message"] = "Uveďte pouze členy týmu, kteří nejsou administrátory. Správci budou mít přístup vždy.";
$lang["google_meet_integration_client_can_access_meetings"] = "Klient má přístup ke schůzkám?";
$lang["google_meet_integration_meeting_time"] = "Čas schůzky";
$lang["google_meet_integration_join_url"] = "Připojit URL";
$lang["google_meet_integration_add_meeting"] = "Přidat schůzku";
$lang["google_meet_integration_edit_meeting"] = "Upravit schůzku";
$lang["google_meet_integration_delete_meeting"] = "Smazat schůzku";
$lang["google_meet_integration_all_client_contacts"] = "Všechny klientské kontakty";
$lang["google_meet_integration_choose_client_contacts"] = "Vyberte kontakty klienta";
$lang["google_meet_integration_upcoming"] = "Připravované";
$lang["google_meet_integration_recent"] = "Nedávné";
$lang["google_meet_integration_past"] = "Minulost";

return $lang;

<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["google_meet_integration"] = "Integrazione con Google Meet";
$lang["google_meet_integration_meetings"] = "Riunioni";
$lang["google_meet_integration_topic"] = "Argomento";
$lang["google_meet_meetings"] = "Riunioni di Google Meet";
$lang["google_meet"] = "Google Meet";
$lang["google_meet_integration_join_meeting"] = "Partecipa alla riunione";
$lang["google_meet_integration_other_settings"] = "Altre impostazioni";
$lang["google_meet_integration_integrate_google_meet"] = "Integra Google Meet";
$lang["google_meet_integration_who_can_manage_meetings"] = "Chi può gestire le riunioni";
$lang["google_meet_integration_users_help_message"] = "Specifica solo i membri del team non amministratori. Gli amministratori avranno sempre accesso.";
$lang["google_meet_integration_client_can_access_meetings"] = "Il cliente può accedere alle riunioni?";
$lang["google_meet_integration_meeting_time"] = "Ora della riunione";
$lang["google_meet_integration_join_url"] = "URL di partecipazione";
$lang["google_meet_integration_add_meeting"] = "Aggiungi riunione";
$lang["google_meet_integration_edit_meeting"] = "Modifica riunione";
$lang["google_meet_integration_delete_meeting"] = "Elimina riunione";
$lang["google_meet_integration_all_client_contacts"] = "Tutti i contatti del cliente";
$lang["google_meet_integration_choose_client_contacts"] = "Scegli i contatti del cliente";
$lang["google_meet_integration_upcoming"] = "Prossimo";
$lang["google_meet_integration_recent"] = "Recente";
$lang["google_meet_integration_past"] = "Passato";

return $lang;

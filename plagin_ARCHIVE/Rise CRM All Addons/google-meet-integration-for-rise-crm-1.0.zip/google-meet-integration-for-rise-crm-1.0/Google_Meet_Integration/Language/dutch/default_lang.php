<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["google_meet_integration"] = "Google Meet-integratie";
$lang["google_meet_integration_meetings"] = "Vergaderingen";
$lang["google_meet_integration_topic"] = "Onderwerp";
$lang["google_meet_meetings"] = "Google Meet-vergaderingen";
$lang["google_meet"] = "Google Meet";
$lang["google_meet_integration_join_meeting"] = "Deelnemen aan vergadering";
$lang["google_meet_integration_other_settings"] = "Andere instellingen";
$lang["google_meet_integration_integrate_google_meet"] = "Google Meet integreren";
$lang["google_meet_integration_who_can_manage_meetings"] = "Wie kan vergaderingen beheren";
$lang["google_meet_integration_users_help_message"] = "Geef alleen niet-beheerdersteamleden op. Beheerders krijgen altijd toegang.";
$lang["google_meet_integration_client_can_access_meetings"] = "Klant heeft toegang tot vergaderingen?";
$lang["google_meet_integration_meeting_time"] = "Vergadertijd";
$lang["google_meet_integration_join_url"] = "Deelnemen aan URL";
$lang["google_meet_integration_add_meeting"] = "Vergadering toevoegen";
$lang["google_meet_integration_edit_meeting"] = "Vergadering bewerken";
$lang["google_meet_integration_delete_meeting"] = "Verwijder vergadering";
$lang["google_meet_integration_all_client_contacts"] = "Alle klantcontacten";
$lang["google_meet_integration_choose_client_contacts"] = "Kies klantcontacten";
$lang["google_meet_integration_upcoming"] = "Aankomend";
$lang["google_meet_integration_recent"] = "Recent";
$lang["google_meet_integration_past"] = "Verleden";

return $lang;

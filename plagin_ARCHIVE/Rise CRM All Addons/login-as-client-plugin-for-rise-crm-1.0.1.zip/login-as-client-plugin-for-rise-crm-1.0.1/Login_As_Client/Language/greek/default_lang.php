<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["login_as_client"] = "Σύνδεση ως πελάτης";
$lang["login_as_client_login"] = "Είσοδος";
$lang["login_as_client_login_back_to_admin"] = "Συνδεθείτε ξανά στο Admin";

return $lang;

<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["login_as_client"] = "Login como cliente";
$lang["login_as_client_login"] = "Login";
$lang["login_as_client_login_back_to_admin"] = "Faça login novamente no administrador";

return $lang;

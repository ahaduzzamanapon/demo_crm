<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["login_as_client"] = "Přihlásit se jako klient";
$lang["login_as_client_login"] = "Přihlášení";
$lang["login_as_client_login_back_to_admin"] = "Přihlásit se zpět do správce";

return $lang;

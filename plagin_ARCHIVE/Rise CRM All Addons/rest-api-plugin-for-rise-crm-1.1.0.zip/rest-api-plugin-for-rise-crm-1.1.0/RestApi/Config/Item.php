<?php
namespace RestApi\Config;

use CodeIgniter\Config\BaseConfig;

class Item extends BaseConfig {
	public $product_item_id = '34115813';
}

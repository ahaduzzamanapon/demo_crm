<?php
//copy from default_lang.php file and update

$lang["example"]            = "Example";
$lang["rest_api_main_menu"] = "API";
return $lang;

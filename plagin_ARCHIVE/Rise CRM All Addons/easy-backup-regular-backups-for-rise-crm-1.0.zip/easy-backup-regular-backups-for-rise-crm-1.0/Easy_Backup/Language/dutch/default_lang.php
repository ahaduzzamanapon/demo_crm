<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["easy_backup"] = "Eenvoudige back-up";
$lang["easy_backup_backup_and_download_now"] = "Back-up en download nu";
$lang["easy_backup_help_message"] = "Als je Google Drive hebt geïntegreerd, worden alle back-ups daar naartoe geüpload, anders worden ze geüpload naar de lokale map van je server.";

return $lang;

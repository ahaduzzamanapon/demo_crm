<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["easy_backup"] = "Einfaches Backup";
$lang["easy_backup_backup_and_download_now"] = "Jetzt sichern und herunterladen";
$lang["easy_backup_help_message"] = "Wenn Sie Google Drive integriert haben, werden alle Backups dorthin hochgeladen, andernfalls werden sie in das lokale Verzeichnis Ihres Servers hochgeladen.";

return $lang;

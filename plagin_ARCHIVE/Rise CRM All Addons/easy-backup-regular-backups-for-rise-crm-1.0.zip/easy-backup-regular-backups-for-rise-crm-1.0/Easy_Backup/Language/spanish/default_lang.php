<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["easy_backup"] = "Copia de seguridad fácil";
$lang["easy_backup_backup_and_download_now"] = "Copia de seguridad y descarga ahora";
$lang["easy_backup_help_message"] = "Si ha integrado Google Drive, todas las copias de seguridad se cargarán allí; de lo contrario, se cargarán en el directorio local de su servidor.";

return $lang;

<?php //copy from default_lang.php file and update

$lang["easy_backup_example"] = "Example";

return $lang;
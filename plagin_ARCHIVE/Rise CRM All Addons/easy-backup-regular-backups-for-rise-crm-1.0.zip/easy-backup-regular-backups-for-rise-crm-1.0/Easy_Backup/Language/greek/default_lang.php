<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["easy_backup"] = "Εύκολη δημιουργία αντιγράφων ασφαλείας";
$lang["easy_backup_backup_and_download_now"] = "Δημιουργία αντιγράφων ασφαλείας & λήψη τώρα";
$lang["easy_backup_help_message"] = "Εάν έχετε ενσωματώσει το Google Drive, όλα τα αντίγραφα ασφαλείας θα μεταφορτωθούν εκεί, διαφορετικά θα μεταφορτωθούν στον τοπικό κατάλογο του διακομιστή σας.";

return $lang;

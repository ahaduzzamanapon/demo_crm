<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["easy_backup"] = "Backup fácil";
$lang["easy_backup_backup_and_download_now"] = "Backup e download agora";
$lang["easy_backup_help_message"] = "Se você integrou o Google Drive, todos os backups serão enviados para lá, caso contrário, serão enviados para o diretório local do seu servidor.";

return $lang;

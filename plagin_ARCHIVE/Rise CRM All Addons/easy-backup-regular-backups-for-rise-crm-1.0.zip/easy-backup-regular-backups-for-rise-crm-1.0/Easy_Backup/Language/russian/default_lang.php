<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["easy_backup"] = "Простое резервное копирование";
$lang["easy_backup_backup_and_download_now"] = "Сделать резервную копию и скачать сейчас";
$lang["easy_backup_help_message"] = "Если вы интегрировали Google Диск, все резервные копии будут загружены туда, в противном случае они будут загружены в локальный каталог вашего сервера.";

return $lang;

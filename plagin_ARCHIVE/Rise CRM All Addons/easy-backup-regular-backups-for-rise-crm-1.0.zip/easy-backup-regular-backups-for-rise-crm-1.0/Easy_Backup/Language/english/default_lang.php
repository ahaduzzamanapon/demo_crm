<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["easy_backup"] = "Easy Backup";
$lang["easy_backup_backup_and_download_now"] = "Backup & download now";
$lang["easy_backup_help_message"] = "If you've integrated Google Drive, all backups will be uploaded to there, otherwise it'll be uploaded to your server's local directory.";

return $lang;

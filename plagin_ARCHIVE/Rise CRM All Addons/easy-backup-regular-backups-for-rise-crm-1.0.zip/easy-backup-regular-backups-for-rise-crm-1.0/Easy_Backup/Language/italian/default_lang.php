<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["easy_backup"] = "Backup facile";
$lang["easy_backup_backup_and_download_now"] = "Backup e download ora";
$lang["easy_backup_help_message"] = "Se hai integrato Google Drive, tutti i backup verranno caricati lì, altrimenti verranno caricati nella directory locale del tuo server.";

return $lang;

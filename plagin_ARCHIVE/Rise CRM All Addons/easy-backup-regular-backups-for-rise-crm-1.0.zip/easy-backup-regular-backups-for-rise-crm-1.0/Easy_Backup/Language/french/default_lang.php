<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["easy_backup"] = "Sauvegarde facile";
$lang["easy_backup_backup_and_download_now"] = "Sauvegarder et télécharger maintenant";
$lang["easy_backup_help_message"] = "Si vous avez intégré Google Drive, toutes les sauvegardes y seront téléchargées, sinon elles seront téléchargées dans le répertoire local de votre serveur.";

return $lang;

<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["easy_backup"] = "Łatwa kopia zapasowa";
$lang["easy_backup_backup_and_download_now"] = "Utwórz kopię zapasową i pobierz teraz";
$lang["easy_backup_help_message"] = "Jeśli zintegrowałeś Dysk Google, wszystkie kopie zapasowe zostaną tam przesłane, w przeciwnym razie zostaną przesłane do lokalnego katalogu twojego serwera.";

return $lang;

<?php //copy from default_lang.php file and update

$lang["social_login_example"] = "Example";

return $lang;
<div id="page-content" class="page-wrapper clearfix">
    <div class="row">
        <div class="col-sm-3 col-lg-2">
            <?php
            $tab_view['active_tab'] = "twofactor";
            echo view("settings/tabs", $tab_view);
            ?>
        </div>

        <div class="col-sm-9 col-lg-10">
            <?php echo form_open(get_uri("twofactor_settings/save_twofactor_settings"), array("id" => "twofactor-settings-form", "class" => "general-form dashed-row", "role" => "form")); ?>
            <div class="card">
                <div class="card-header">
                    <h4><?php echo app_lang("twofactor_settings"); ?></h4>
                </div>
                <div class="card-body">

                    <div class="form-group">
                        <div class="row">
                            <label for="twofactor_email_subject" class=" col-md-2"><?php echo app_lang('twofactor_email_subject'); ?></label>
                            <div class=" col-md-10">
                                <?php
                                echo form_input(array(
                                    "id" => "twofactor_email_subject",
                                    "name" => "twofactor_email_subject",
                                    "value" => get_twofactor_setting('twofactor_email_subject'),
                                    "class" => "form-control",
                                    "placeholder" => app_lang("subject"),
                                    "data-rule-required" => true,
                                    "data-msg-required" => app_lang("field_required"),
                                ));
                                ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <div class="row">
                            <label for="twofactor_email_custom_message" class=" col-md-2"><?php echo app_lang('twofactor_email_message'); ?></label>
                            <div class="col-md-10">
                                <?php
                                echo form_textarea(array(
                                    "id" => "twofactor_email_custom_message",
                                    "name" => "twofactor_email_custom_message",
                                    "value" => get_twofactor_setting('twofactor_email_custom_message') ? get_twofactor_setting('twofactor_email_custom_message') : get_twofactor_setting('twofactor_email_default_message'),
                                    "class" => "form-control",
                                ));
                                ?>

                                <div class="mt15"><strong><?php echo app_lang("avilable_variables"); ?></strong>: <?php
                                    $variables = array("FIRST_NAME", "LAST_NAME", "LOGIN_EMAIL", "CODE", "APP_TITLE", "COMPANY_NAME", "LOGO_URL", "SIGNATURE");
                                    foreach ($variables as $variable) {
                                        echo "{" . $variable . "}, ";
                                    }
                                    ?></div>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <button type="submit" class="btn btn-primary"><span data-feather="check-circle" class="icon-16"></span> <?php echo app_lang('save'); ?></button>
                    <button id="twofactor_restore_email_message_to_default" data-bs-toggle="popover" data-placement="top" type="button" class="btn btn-danger ml5"><span data-feather="refresh-cw" class="icon-16"></span> <?php echo app_lang('twofactor_restore_email_message_to_default'); ?></button>
                </div>
                <?php echo form_close(); ?>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(document).ready(function () {
        "use strict";

        $("#twofactor-settings-form").appForm({
            isModal: false,
            beforeAjaxSubmit: function (data) {
                var custom_message = encodeAjaxPostData(getWYSIWYGEditorHTML("#twofactor_email_custom_message"));
                $.each(data, function (index, obj) {
                    if (obj.name === "twofactor_email_custom_message") {
                        data[index]["value"] = custom_message;
                    }
                });
            },
            onSubmit: function () {
                appLoader.show();
            },
            onSuccess: function (result) {
                appLoader.hide();
                appAlert.success(result.message, {duration: 10000});
            },
            onError: function (result) {
                appLoader.hide();
                appAlert.error(result.message);
            }
        });

        initWYSIWYGEditor("#twofactor_email_custom_message", {height: 480});

        $('#twofactor_restore_email_message_to_default').click(function () {
            var $instance = $(this);
            $(this).appConfirmation({
                title: "<?php echo app_lang('are_you_sure'); ?>",
                btnConfirmLabel: "<?php echo app_lang('yes'); ?>",
                btnCancelLabel: "<?php echo app_lang('no'); ?>",
                onConfirm: function () {
                    $.ajax({
                        url: "<?php echo get_uri('twofactor_settings/restore_message_to_default') ?>",
                        type: 'POST',
                        dataType: 'json',
                        success: function (result) {
                            if (result.success) {
                                $('#twofactor_email_custom_message').summernote('code', result.data);
                                appAlert.success(result.message, {duration: 10000});
                            } else {
                                appAlert.error(result.message);
                            }
                        }
                    });

                }
            });

            return false;
        });

    });
</script>
<div class="tab-content">
    <?php
    $user_id = $login_user->id;
    echo form_open(get_uri("twofactor_settings/save_user_settings/"), array("id" => "twofactor-setting-form", "class" => "general-form dashed-row white", "role" => "form"));
    ?>
    <div class="card">
        <div class=" card-header">
            <h4> <?php echo app_lang('twofactor_twofactor_authentication'); ?></h4>
        </div>
        <div class="card-body">

            <div class="form-group">
                <div class="row">
                    <label for="enable_twofactor_authentication" class=" col-md-3"><?php echo app_lang('twofactor_enable_twofactor_authentication'); ?></label>
                    <div class=" col-md-9">
                        <?php
                        echo form_checkbox("enable_twofactor_authentication", "1", get_twofactor_setting('user_' . $user_id . '_enable_twofactor_authentication') ? true : false, "id='enable_twofactor_authentication' class='form-check-input ml15 mt5'");
                        ?>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <div class="row">
                    <div class="col-md-12">
                        <i data-feather="info" class="icon-16"></i>
                        <span><?php echo app_lang("twofactor_info_text"); ?></span>
                    </div>
                </div>
            </div>

        </div>
        <div class="card-footer rounded-0">
            <button type="submit" class="btn btn-primary"><span data-feather="check-circle" class="icon-16"></span> <?php echo app_lang('save'); ?></button>
        </div>
    </div>
    <?php echo form_close(); ?>
</div>

<script type="text/javascript">
    "use strict";

    $(document).ready(function () {
        $("#twofactor-setting-form").appForm({
            isModal: false,
            onSuccess: function (result) {
                appAlert.success(result.message, {duration: 10000});
            }
        });
    });
</script>    
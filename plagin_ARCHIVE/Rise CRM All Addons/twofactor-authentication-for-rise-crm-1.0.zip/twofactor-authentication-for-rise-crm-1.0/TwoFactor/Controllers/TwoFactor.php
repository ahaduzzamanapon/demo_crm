<?php

namespace TwoFactor\Controllers;

use App\Controllers\Security_Controller;

class TwoFactor extends Security_Controller {

    protected $TwoFactor_verification_model;

    function __construct() {
        parent::__construct(false);
        if (!isset($this->login_user->id)) {
            show_404();
        }

        $this->TwoFactor_verification_model = new \TwoFactor\Models\TwoFactor_verification_model();
    }

    function index() {
        helper('cookie');
        $has_cookie = get_cookie("twofactor_cookie_of_user" . $this->login_user->id);
        if (!get_twofactor_setting('user_' . $this->login_user->id . '_enable_twofactor_authentication') || $has_cookie) {
            app_redirect("dashboard/view");
        }

        //check if there has any valid code for this user
        //if exists, don't send a new one
        $options = array("email" => $this->login_user->email);
        $verifications = $this->TwoFactor_verification_model->get_details($options)->getResult();
        foreach ($verifications as $verification) {
            if ($this->is_valid_twofactor_code($verification->code)) {
                return $this->template->view('TwoFactor\Views\twofactor\index');
            }
        }

        //save code
        $code = rand(1000, 9999) . rand(1000, 9999);
        $verification_data = array(
            "code" => $code, //make 8 digit random code
            "params" => serialize(array(
                "email" => $this->login_user->email,
                "expire_time" => time() + (2 * 60 * 60) //make the code with 2hrs validity
            ))
        );

        //send code
        $parser_data["CODE"] = $code;
        $parser_data["FIRST_NAME"] = $this->login_user->first_name;
        $parser_data["LAST_NAME"] = $this->login_user->last_name;
        $parser_data["LOGIN_EMAIL"] = $this->login_user->email;
        $parser_data["APP_TITLE"] = get_setting("app_title");
        $parser_data["COMPANY_NAME"] = get_setting("company_name");
        $parser_data["LOGO_URL"] = get_logo_url();

        $email_template = $this->Email_templates_model->get_final_template("signature");
        $parser_data["SIGNATURE"] = $email_template->signature;

        //send email
        $message = get_twofactor_setting('twofactor_email_custom_message') ? get_twofactor_setting('twofactor_email_custom_message') : get_twofactor_setting('twofactor_email_default_message');
        $message = $this->parser->setData($parser_data)->renderString($message);

        if (send_app_mail($this->login_user->email, get_twofactor_setting('twofactor_email_subject'), $message)) {
            //save verification code after sending email
            $save_id = $this->TwoFactor_verification_model->ci_save($verification_data);
            if (!$save_id) {
                show_404();
            }

            //show two-factor form
            return $this->template->view('TwoFactor\Views\twofactor\index');
        } else {
            show_404();
        }
    }

    function authenticate() {
        $this->validate_submitted_data(array(
            "twofactor_code" => "required|numeric",
        ));

        $verification_code = $this->request->getPost("twofactor_code");
        if ($this->is_valid_twofactor_code($verification_code)) {
            //the code is valid, delete the code
            $options = array("code" => $verification_code);
            $verification_info = $this->TwoFactor_verification_model->get_details($options)->getRow();
            if ($verification_info->id) {
                $this->TwoFactor_verification_model->delete_permanently($verification_info->id);
            }

            //redirect to dashboard
            twofactor_set_cookie("twofactor_cookie_of_user_" . $this->login_user->id, "1");
            echo json_encode(array("success" => true, "message" => app_lang("twofactor_code_success_message")));
            exit;
        }

        echo json_encode(array("success" => false, 'message' => app_lang("twofactor_code_expaired_message")));
    }

    //check valid code
    private function is_valid_twofactor_code($verification_code = "") {
        if ($verification_code) {
            $options = array("code" => $verification_code);
            $verification_info = $this->TwoFactor_verification_model->get_details($options)->getRow();

            if ($verification_info && $verification_info->id) {
                $invitation_info = unserialize($verification_info->params);

                $email = get_array_value($invitation_info, "email");
                $expire_time = get_array_value($invitation_info, "expire_time");

                if ($email && filter_var($email, FILTER_VALIDATE_EMAIL) && $email === $this->login_user->email && $expire_time && $expire_time > time()) {
                    return true;
                }
            }
        }
    }

}

<?php

namespace TwoFactor\Controllers;

use App\Controllers\Security_Controller;

class TwoFactor_settings extends Security_Controller {

    protected $TwoFactor_settings_model;

    function __construct() {
        parent::__construct();
        $this->TwoFactor_settings_model = new \TwoFactor\Models\TwoFactor_settings_model();
    }

    function user_settings() {
        return $this->template->view("TwoFactor\Views\settings\user_settings");
    }

    function save_user_settings() {
        $settings = array("enable_twofactor_authentication");

        foreach ($settings as $setting) {
            $value = $this->request->getPost($setting);
            if (is_null($value)) {
                $value = "";
            }

            //save the cookie to this browser while activating two-factor
            if ($value) {
                twofactor_set_cookie("twofactor_cookie_of_user_" . $this->login_user->id, "1");
            }

            $this->TwoFactor_settings_model->save_setting("user_" . $this->login_user->id . "_" . $setting, $value, "user");
        }

        echo json_encode(array("success" => true, 'message' => app_lang('settings_updated')));
    }

    function index() {
        $this->access_only_admin_or_settings_admin();
        return $this->template->rander("TwoFactor\Views\settings\index");
    }

    function save_twofactor_settings() {
        $this->access_only_admin_or_settings_admin();
        $settings = array("twofactor_email_subject", "twofactor_email_custom_message");

        foreach ($settings as $setting) {
            $value = $this->request->getPost($setting);
            if ($setting === "twofactor_email_custom_message") {
                $value = decode_ajax_post_data($value);
            }

            if (is_null($value)) {
                $value = "";
            }

            $this->TwoFactor_settings_model->save_setting($setting, $value);
        }

        echo json_encode(array("success" => true, 'message' => app_lang('settings_updated')));
    }

    function restore_message_to_default() {
        $this->access_only_admin_or_settings_admin();
        $this->TwoFactor_settings_model->save_setting("twofactor_email_custom_message", "");
        echo json_encode(array("success" => true, "data" => get_twofactor_setting("twofactor_email_default_message"), 'message' => app_lang('twofactor_email_message_restored')));
    }

}

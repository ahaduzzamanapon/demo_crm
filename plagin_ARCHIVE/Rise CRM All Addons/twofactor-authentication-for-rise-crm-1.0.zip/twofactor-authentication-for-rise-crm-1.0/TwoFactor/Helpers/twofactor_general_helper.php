<?php

/**
 * get the defined config value by a key
 * @param string $key
 * @return config value
 */
if (!function_exists('get_twofactor_setting')) {

    function get_twofactor_setting($key = "") {
        $config = new TwoFactor\Config\TwoFactor();

        $setting_value = get_array_value($config->app_settings_array, $key);
        if ($setting_value !== NULL) {
            return $setting_value;
        } else {
            return "";
        }
    }

}

if (!function_exists('twofactor_set_cookie')) {

    function twofactor_set_cookie($name = "", $value = "") {
        if (!$name) {
            return false;
        }

        $secure = false;
        if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
            $secure = true;
        }

        setcookie($name, $value, 0, '/', '', $secure);
    }

}

<?php //copy from default_lang.php file and update

$lang["twofactor_example"] = "Example";

return $lang;
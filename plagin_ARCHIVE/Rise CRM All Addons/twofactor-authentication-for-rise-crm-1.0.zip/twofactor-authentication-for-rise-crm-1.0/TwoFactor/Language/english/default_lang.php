<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["twofactor"] = "Two-factor";
$lang["twofactor_settings"] = "Two-factor settings";
$lang["twofactor_email_subject"] = "Email subject";
$lang["twofactor_email_message"] = "Email message";
$lang["twofactor_twofactor_authentication"] = "Two-factor authentication";
$lang["twofactor_enable_twofactor_authentication"] = "Enable two-factor authentication";
$lang["twofactor_info_text"] = "Before you logout, please open a new browser and make sure the Two-factor authentication is working.";
$lang["twofactor_code"] = "Code";
$lang["twofactor_code_expaired_message"] = "The two-factor code has expired or something went wrong.";
$lang["twofactor_code_message"] = "An OTP has been sent to your email. Please grab that to continue.";
$lang["twofactor_code_success_message"] = "Logged in successfully. Redirecting to the dashboard...";
$lang["twofactor_continue"] = "Continue";
$lang["twofactor_not_you"] = "Not you?";
$lang["twofactor_restore_email_message_to_default"] = "Restore email message to default";
$lang["twofactor_email_message_restored"] = "The email message has been restored to default!";

return $lang;

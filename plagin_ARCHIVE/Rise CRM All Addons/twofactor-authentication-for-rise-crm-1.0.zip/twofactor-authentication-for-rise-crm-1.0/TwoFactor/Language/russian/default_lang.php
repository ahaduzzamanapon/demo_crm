<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["twofactor"] = "Двухфакторный";
$lang["twofactor_settings"] = "Двухфакторные настройки";
$lang["twofactor_email_subject"] = "Тема письма";
$lang["twofactor_email_message"] = "Электронное сообщение";
$lang["twofactor_twofactor_authentication"] = "Двухфакторная аутентификация";
$lang["twofactor_enable_twofactor_authentication"] = "Включить двухфакторную аутентификацию";
$lang["twofactor_info_text"] = "Перед выходом откройте новый браузер и убедитесь, что двухфакторная аутентификация работает.";
$lang["twofactor_code"] = "Код";
$lang["twofactor_code_expaired_message"] = "Срок действия двухфакторного кода истек или что-то пошло не так.";
$lang["twofactor_code_message"] = "На вашу электронную почту был отправлен одноразовый пароль. Используйте его, чтобы продолжить.";
$lang["twofactor_code_success_message"] = "Выполнен вход в систему. Перенаправление на панель управления ...";
$lang["twofactor_continue"] = "Продолжить";
$lang["twofactor_not_you"] = "Не ты?";
$lang["twofactor_restore_email_message_to_default"] = "Восстановить сообщение электронной почты по умолчанию";
$lang["twofactor_email_message_restored"] = "Сообщение электронной почты восстановлено по умолчанию!";

return $lang;

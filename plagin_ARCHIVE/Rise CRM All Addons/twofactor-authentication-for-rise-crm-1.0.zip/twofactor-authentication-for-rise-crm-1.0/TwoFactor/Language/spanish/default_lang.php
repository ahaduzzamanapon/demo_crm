<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["twofactor"] = "Dos factores";
$lang["twofactor_settings"] = "Configuración de dos factores";
$lang["twofactor_email_subject"] = "Asunto del correo electrónico";
$lang["twofactor_email_message"] = "Mensaje de correo electrónico";
$lang["twofactor_twofactor_authentication"] = "Autenticación de dos factores";
$lang["twofactor_enable_twofactor_authentication"] = "Habilitar la autenticación de dos factores";
$lang["twofactor_info_text"] = "Antes de cerrar la sesión, abra un nuevo navegador y asegúrese de que la autenticación de dos factores esté funcionando";
$lang["twofactor_code"] = "Código";
$lang["twofactor_code_expaired_message"] = "El código de dos factores ha expirado o algo salió mal.";
$lang["twofactor_code_message"] = "Se ha enviado una OTP a su correo electrónico. Tómela para continuar.";
$lang["twofactor_code_success_message"] = "Inicio de sesión exitoso. Redirigiendo al tablero ...";
$lang["twofactor_continue"] = "Continuar";
$lang["twofactor_not_you"] = "¿Tú no?";
$lang["twofactor_restore_email_message_to_default"] = "Restaurar el mensaje de correo electrónico a los valores predeterminados";
$lang["twofactor_email_message_restored"] = "¡El mensaje de correo electrónico ha sido restaurado a los valores predeterminados!";

return $lang;

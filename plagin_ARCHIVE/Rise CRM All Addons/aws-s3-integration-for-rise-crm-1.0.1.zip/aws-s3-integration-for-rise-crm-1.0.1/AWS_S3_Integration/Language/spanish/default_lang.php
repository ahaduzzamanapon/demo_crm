<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["aws_s3_integration_integrate"] = "Integrar";
$lang["aws_s3_integration_access_key_id"] = "ID de clave de acceso";
$lang["aws_s3_integration_secret_access_key"] = "Clave de acceso secreta";
$lang["aws_s3_integration_bucket_name"] = "Nombre del depósito";
$lang["aws_s3_integration_bucket_naming_help_message"] = "El nombre del depósito debe ser único y no debe contener espacios ni letras mayúsculas.";
$lang["aws_s3_integration_see_rules_for_bucket_naming"] = "Ver reglas para la denominación de depósitos";
$lang["aws_s3_integration_get_your_access_keys_from_here"] = "Obtenga sus claves de acceso desde aquí";
$lang["aws_s3_integration_region"] = "Región";

return $lang;

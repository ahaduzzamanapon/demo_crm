<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["aws_s3_integration_integrate"] = "Integrieren";
$lang["aws_s3_integration_access_key_id"] = "Zugriffsschlüssel-ID";
$lang["aws_s3_integration_secret_access_key"] = "Geheimer Zugriffsschlüssel";
$lang["aws_s3_integration_bucket_name"] = "Bucket-Name";
$lang["aws_s3_integration_bucket_naming_help_message"] = "Bucket-Name muss eindeutig sein und darf keine Leerzeichen oder Großbuchstaben enthalten.";
$lang["aws_s3_integration_see_rules_for_bucket_naming"] = "Siehe Regeln für Bucket-Benennung";
$lang["aws_s3_integration_get_your_access_keys_from_here"] = "Holen Sie sich hier Ihre Zugangsschlüssel";
$lang["aws_s3_integration_region"] = "Region";

return $lang;

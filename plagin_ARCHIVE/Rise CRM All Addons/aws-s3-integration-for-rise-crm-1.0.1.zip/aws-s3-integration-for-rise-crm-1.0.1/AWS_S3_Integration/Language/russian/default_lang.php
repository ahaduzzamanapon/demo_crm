<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["aws_s3_integration_integrate"] = "Интегрировать";
$lang["aws_s3_integration_access_key_id"] = "Идентификатор ключа доступа";
$lang["aws_s3_integration_secret_access_key"] = "Секретный ключ доступа";
$lang["aws_s3_integration_bucket_name"] = "Имя сегмента";
$lang["aws_s3_integration_bucket_naming_help_message"] = "Имя сегмента должно быть уникальным и не должно содержать пробелов или заглавных букв.";
$lang["aws_s3_integration_see_rules_for_bucket_naming"] = "См. правила именования сегментов";
$lang["aws_s3_integration_get_your_access_keys_from_here"] = "Получите ключи доступа отсюда";
$lang["aws_s3_integration_region"] = "Регион";

return $lang;

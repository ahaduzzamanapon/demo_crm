<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["aws_s3_integration_integrate"] = "Integra";
$lang["aws_s3_integration_access_key_id"] = "ID chiave di accesso";
$lang["aws_s3_integration_secret_access_key"] = "Chiave di accesso segreta";
$lang["aws_s3_integration_bucket_name"] = "Nome del secchio";
$lang["aws_s3_integration_bucket_naming_help_message"] = "Il nome del bucket deve essere univoco e non deve contenere spazi o lettere maiuscole.";
$lang["aws_s3_integration_see_rules_for_bucket_naming"] = "Consulta le regole per la denominazione dei bucket";
$lang["aws_s3_integration_get_your_access_keys_from_here"] = "Ottieni le tue chiavi di accesso da qui";
$lang["aws_s3_integration_region"] = "Regione";

return $lang;

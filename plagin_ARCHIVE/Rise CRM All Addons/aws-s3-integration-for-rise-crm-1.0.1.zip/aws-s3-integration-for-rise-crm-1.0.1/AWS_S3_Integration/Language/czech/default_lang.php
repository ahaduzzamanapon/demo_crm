<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["aws_s3_integration_integrate"] = "Integrovat";
$lang["aws_s3_integration_access_key_id"] = "ID přístupového klíče";
$lang["aws_s3_integration_secret_access_key"] = "Klíč tajného přístupu";
$lang["aws_s3_integration_bucket_name"] = "Název segmentu";
$lang["aws_s3_integration_bucket_naming_help_message"] = "Název segmentu musí být jedinečný a nesmí obsahovat mezery ani velká písmena.";
$lang["aws_s3_integration_see_rules_for_bucket_naming"] = "Viz pravidla pro pojmenování bucket";
$lang["aws_s3_integration_get_your_access_keys_from_here"] = "Získejte přístupové klíče odtud";
$lang["aws_s3_integration_region"] = "Region";

return $lang;

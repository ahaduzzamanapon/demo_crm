<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["aws_s3_integration_integrate"] = "Ενσωμάτωση";
$lang["aws_s3_integration_access_key_id"] = "Αναγνωριστικό κλειδιού πρόσβασης";
$lang["aws_s3_integration_secret_access_key"] = "Μυστικό κλειδί πρόσβασης";
$lang["aws_s3_integration_bucket_name"] = "Όνομα κάδου";
$lang["aws_s3_integration_bucket_naming_help_message"] = "Το όνομα του κάδου πρέπει να είναι μοναδικό και να μην περιέχει κενά ή κεφαλαία γράμματα.";
$lang["aws_s3_integration_see_rules_for_bucket_naming"] = "Δείτε κανόνες για την ονομασία του κάδου";
$lang["aws_s3_integration_get_your_access_keys_from_here"] = "Λάβετε τα κλειδιά πρόσβασης από εδώ";
$lang["aws_s3_integration_region"] = "Περιοχή";

return $lang;

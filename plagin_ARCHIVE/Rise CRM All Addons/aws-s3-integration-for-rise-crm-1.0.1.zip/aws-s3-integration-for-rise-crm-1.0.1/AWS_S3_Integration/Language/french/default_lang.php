<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["aws_s3_integration_integrate"] = "Intégrer";
$lang["aws_s3_integration_access_key_id"] = "ID de la clé d'accès";
$lang["aws_s3_integration_secret_access_key"] = "Clé d'accès secrète";
$lang["aws_s3_integration_bucket_name"] = "Nom du compartiment";
$lang["aws_s3_integration_bucket_naming_help_message"] = "Le nom du compartiment doit être unique et ne doit pas contenir d'espaces ni de lettres majuscules.";
$lang["aws_s3_integration_see_rules_for_bucket_naming"] = "Voir les règles de dénomination des buckets";
$lang["aws_s3_integration_get_your_access_keys_from_here"] = "Obtenez vos clés d'accès ici";
$lang["aws_s3_integration_region"] = "Région";

return $lang;

<?php

namespace Zoom_Integration\Controllers;

use App\Controllers\Security_Controller;
use Zoom_Integration\Libraries\Zoom_Integration;

class Zoom_Integration_settings extends Security_Controller {

    protected $Zoom_Integration_settings_model;

    function __construct() {
        parent::__construct();
        $this->access_only_admin_or_settings_admin();
        $this->Zoom_Integration_settings_model = new \Zoom_Integration\Models\Zoom_Integration_settings_model();
    }

    function index() {
        return $this->template->rander("Zoom_Integration\Views\settings\index");
    }

    function other_settings() {
        $team_members = $this->Users_model->get_all_where(array("deleted" => 0, "user_type" => "staff", "is_admin" => 0))->getResult();
        $members_dropdown = array();

        foreach ($team_members as $team_member) {
            $members_dropdown[] = array("id" => $team_member->id, "text" => $team_member->first_name . " " . $team_member->last_name);
        }

        $view_data['members_dropdown'] = json_encode($members_dropdown);

        return $this->template->view("Zoom_Integration\Views\settings\other_settings", $view_data);
    }

    function save_other_settings() {
        $settings = array(
            "zoom_integration_users", "client_can_access_meetings"
        );

        foreach ($settings as $setting) {
            $value = $this->request->getPost($setting);
            if (is_null($value)) {
                $value = "";
            }

            $this->Zoom_Integration_settings_model->save_setting($setting, $value);
        }
        echo json_encode(array("success" => true, 'message' => app_lang('settings_updated')));
    }

    function save_zoom_integration_settings() {
        $settings = array("integrate_zoom", "zoom_api_key", "zoom_api_secret");

        $integrate_zoom = $this->request->getPost("integrate_zoom");

        foreach ($settings as $setting) {
            $value = $this->request->getPost($setting);
            if (is_null($value)) {
                $value = "";
            }

            //if user change credentials, flag zoom as unauthorized
            if (get_zoom_integration_setting('zoom_authorized') && ($setting == "zoom_api_key" || $setting == "zoom_api_secret") && $integrate_zoom && get_zoom_integration_setting($setting) != $value) {
                $this->Zoom_Integration_settings_model->save_setting('zoom_authorized', "0");
            }

            $this->Zoom_Integration_settings_model->save_setting($setting, $value);
        }

        echo json_encode(array("success" => true, 'message' => app_lang('settings_updated')));
    }

    //authorize zoom
    function authorize_zoom() {
        $zoom = new Zoom_Integration();
        $zoom->authorize();
    }

}

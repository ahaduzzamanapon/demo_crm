<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["zoom_integration"] = "Ενσωμάτωση Zoom";
$lang["zoom_integration_meetings"] = "Συναντήσεις";
$lang["zoom_integration_topic"] = "Θέμα";
$lang["zoom_meetings"] = "Συσκέψεις Zoom";
$lang["zoom_integration_join_meeting"] = "Συμμετοχή στη συνάντηση";
$lang["zoom_integration_other_settings"] = "Άλλες ρυθμίσεις";
$lang["zoom_integration_integrate_zoom"] = "Ενσωμάτωση Zoom";
$lang["zoom_integration_who_can_manage_meetings"] = "Ποιος μπορεί να διαχειρίζεται συσκέψεις";
$lang["zoom_integration_users_help_message"] = "Καθορίστε μόνο μέλη της ομάδας που δεν είναι διαχειριστές. Οι διαχειριστές θα έχουν πάντα πρόσβαση.";
$lang["zoom_integration_client_can_access_meetings"] = "Ο πελάτης μπορεί να έχει πρόσβαση σε συσκέψεις;";
$lang["zoom_integration_meeting_time"] = "Ώρα συνάντησης";
$lang["zoom_integration_join_url"] = "Διεύθυνση URL συμμετοχής";
$lang["zoom_integration_add_meeting"] = "Προσθήκη συνάντησης";
$lang["zoom_integration_edit_meeting"] = "Επεξεργασία συνάντησης";
$lang["zoom_integration_delete_meeting"] = "Διαγραφή συνάντησης";
$lang["zoom_integration_all_client_contacts"] = "Όλες οι επαφές πελατών";
$lang["zoom_integration_choose_client_contacts"] = "Επιλογή επαφών πελάτη";
$lang["zoom_integration_upcoming"] = "Προσεχόμενα";
$lang["zoom_integration_running"] = "Εκτέλεση";
$lang["zoom_integration_past"] = "Παρελθόν";
$lang["zoom_integration_in_minutes"] = "Σε λεπτά";
$lang["zoom_integration_minutes"] = "Λεπτά";
$lang["zoom_integration_duration"] = "Διάρκεια";

$lang["zoom_integration_enable_waiting_room"] = "Ενεργοποίηση αίθουσας αναμονής";
$lang["zoom_integration_waiting_room_help_message"] = "Όταν οι συμμετέχοντες συμμετέχουν σε μια σύσκεψη, τοποθετήστε τους σε μια αίθουσα αναμονής και ζητήστε από τον οικοδεσπότη να τους δεχθεί μεμονωμένα.";

$lang["zoom_integration_api_key"] = "Κλειδί API";
$lang["zoom_integration_api_secret"] = "Μυστικό API";

return $lang;

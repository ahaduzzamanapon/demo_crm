<?php //copy from default_lang.php file and update

$lang["zoom_integration_example"] = "Example";

return $lang;
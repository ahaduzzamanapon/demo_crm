<?php

/* Don't change or add any new config in this file */

namespace SMS\Config;

use CodeIgniter\Config\BaseConfig;

class Sms extends BaseConfig {

    public $sms_settings_array = array();

}

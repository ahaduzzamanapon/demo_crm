<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["microsoft_teams_integration"] = "Microsoft Teams-integrering";
$lang["microsoft_teams_integration_meetings"] = "Møter";
$lang["microsoft_teams_integration_topic"] = "Emne";
$lang["microsoft_team_meetings"] = "Teams-møter";
$lang["microsoft_teams_integration_join_meeting"] = "Bli med i møte";
$lang["microsoft_teams_integration_other_settings"] = "Andre innstillinger";
$lang["microsoft_teams_integration_integrate_microsoft_teams"] = "Integrer Microsoft Teams";
$lang["microsoft_teams_integration_who_can_manage_meetings"] = "Hvem kan administrere møter";
$lang["microsoft_teams_integration_users_help_message"] = "Spesifiser kun ikke-admin teammedlemmer. Administratorer vil alltid få tilgang.";
$lang["microsoft_teams_integration_client_can_access_meetings"] = "Klient kan få tilgang til møter?";
$lang["microsoft_teams_integration_meeting_time"] = "Møtetid";
$lang["microsoft_teams_integration_join_url"] = "Bli med URL";
$lang["microsoft_teams_integration_add_meeting"] = "Legg til møte";
$lang["microsoft_teams_integration_edit_meeting"] = "Rediger møte";
$lang["microsoft_teams_integration_delete_meeting"] = "Slett møte";
$lang["microsoft_teams_integration_all_client_contacts"] = "Alle klientkontakter";
$lang["microsoft_teams_integration_choose_client_contacts"] = "Velg klientkontakter";
$lang["microsoft_teams_integration_upcoming"] = "Kommende";
$lang["microsoft_teams_integration_recent"] = "Nylig";
$lang["microsoft_teams_integration_past"] = "Fortid";

return $lang;

<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["jitsi_integration"] = "Integração Jitsi";
$lang["jitsi_integration_meetings"] = "Reuniões";
$lang["jitsi_integration_topic"] = "Tópico";
$lang["jitsi_meetings"] = "Reuniões Jitsi";
$lang["jitsi_integration_join_meeting"] = "Participar da reunião";
$lang["jitsi_integration_enable_jitsi_meetings"] = "Habilitar reuniões Jitsi";
$lang["jitsi_integration_who_can_manage_meetings"] = "Quem pode gerenciar reuniões";
$lang["jitsi_integration_users_help_message"] = "Especifique apenas membros não-administradores da equipe. Os administradores sempre terão acesso.";
$lang["jitsi_integration_client_can_access_meetings"] = "O cliente pode acessar as reuniões?";
$lang["jitsi_integration_meeting_time"] = "Hora da reunião";
$lang["jitsi_integration_join_url"] = "URL de adesão";
$lang["jitsi_integration_add_meeting"] = "Adicionar reunião";
$lang["jitsi_integration_edit_meeting"] = "Editar reunião";
$lang["jitsi_integration_delete_meeting"] = "Excluir reunião";
$lang["jitsi_integration_all_client_contacts"] = "Todos os contatos do cliente";
$lang["jitsi_integration_choose_client_contacts"] = "Escolha os contatos do cliente";
$lang["jitsi_integration_upcoming"] = "Próximos";
$lang["jitsi_integration_recent"] = "Recentes";
$lang["jitsi_integration_past"] = "Passado";

return $lang;

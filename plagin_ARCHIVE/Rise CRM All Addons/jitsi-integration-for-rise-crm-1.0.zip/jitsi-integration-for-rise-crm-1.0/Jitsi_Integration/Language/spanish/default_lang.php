<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["jitsi_integration"] = "Integración Jitsi";
$lang["jitsi_integration_meetings"] = "Reuniones";
$lang["jitsi_integration_topic"] = "Tema";
$lang["jitsi_meetings"] = "Reuniones Jitsi";
$lang["jitsi_integration_join_meeting"] = "Unirse a la reunión";
$lang["jitsi_integration_enable_jitsi_meetings"] = "Habilitar reuniones Jitsi";
$lang["jitsi_integration_who_can_manage_meetings"] = "Quién puede gestionar reuniones";
$lang["jitsi_integration_users_help_message"] = "Especifique solo los miembros del equipo que no sean administradores. Los administradores siempre tendrán acceso.";
$lang["jitsi_integration_client_can_access_meetings"] = "¿El cliente puede acceder a las reuniones?";
$lang["jitsi_integration_meeting_time"] = "Hora de la reunión";
$lang["jitsi_integration_join_url"] = "URL de ingreso";
$lang["jitsi_integration_add_meeting"] = "Agregar reunión";
$lang["jitsi_integration_edit_meeting"] = "Editar reunión";
$lang["jitsi_integration_delete_meeting"] = "Eliminar reunión";
$lang["jitsi_integration_all_client_contacts"] = "Todos los contactos del cliente";
$lang["jitsi_integration_choose_client_contacts"] = "Elija los contactos del cliente";
$lang["jitsi_integration_upcoming"] = "Próximo";
$lang["jitsi_integration_recent"] = "Reciente";
$lang["jitsi_integration_past"] = "Pasado";

return $lang;

<?php echo form_open(get_uri("mailbox_settings/save_smtp_settings"), array("id" => "mailbox-smtp-settings-form", "class" => "general-form bg-white", "role" => "form")); ?>
<div class="modal-body clearfix">
    <div class="container-fluid">
        <input type="hidden" name="id" value="<?php echo $model_info->id; ?>" />

        <div class="form-group">
            <div class="row">
                <label for="use_global_email" class=" col-md-3"><?php echo app_lang('mailbox_use_global_email_settings'); ?></label>
                <div class="col-md-9">
                    <?php
                    echo form_checkbox(
                            "use_global_email", "1", $model_info->use_global_email ? true : false, "id='use_global_email' class='form-check-input'"
                    );
                    ?>
                </div>
            </div>
        </div>
        <div id="all_smtp_settings" class="<?php echo $model_info->use_global_email ? "hide" : ""; ?>">
            <div class="form-group">
                <div class="row">
                    <label for="email_sent_from_address" class=" col-md-3"><?php echo app_lang('email_sent_from_address'); ?></label>
                    <div class=" col-md-9">
                        <?php
                        echo form_input(array(
                            "id" => "email_sent_from_address",
                            "name" => "email_sent_from_address",
                            "value" => $model_info->email_sent_from_address ? $model_info->email_sent_from_address : $model_info->imap_email,
                            "class" => "form-control",
                            "placeholder" => "somemail@somedomain.com",
                            "data-rule-required" => true,
                            "data-msg-required" => app_lang("field_required"),
                        ));
                        ?>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <label for="email_sent_from_name" class=" col-md-3"><?php echo app_lang('email_sent_from_name'); ?></label>
                    <div class="col-md-9">
                        <?php
                        echo form_input(array(
                            "id" => "email_sent_from_name",
                            "name" => "email_sent_from_name",
                            "value" => $model_info->email_sent_from_name ? $model_info->email_sent_from_name : $model_info->title,
                            "class" => "form-control",
                            "data-rule-required" => true,
                            "data-msg-required" => app_lang("field_required"),
                        ));
                        ?>
                    </div>
                </div>
            </div>
            <div class="form-group">
                <div class="row">
                    <label for="use_smtp" class=" col-md-3"><?php echo app_lang('email_use_smtp'); ?></label>
                    <div class="col-md-9">
                        <?php
                        echo form_checkbox(
                                "email_protocol", "smtp", $model_info->email_protocol === "smtp" ? true : false, "id='use_smtp' class='form-check-input'"
                        );
                        ?>
                    </div>
                </div>
            </div>

            <div id="smtp_settings" class="<?php echo $model_info->email_protocol === "smtp" ? "" : "hide"; ?>">
                <div class="form-group">
                    <div class="row">
                        <label for="email_smtp_host" class=" col-md-3"><?php echo app_lang('email_smtp_host'); ?></label>
                        <div class="col-md-9">
                            <?php
                            echo form_input(array(
                                "id" => "email_smtp_host",
                                "name" => "email_smtp_host",
                                "value" => $model_info->email_smtp_host,
                                "class" => "form-control",
                                "placeholder" => app_lang('email_smtp_host'),
                                "data-rule-required" => true,
                                "data-msg-required" => app_lang("field_required"),
                            ));
                            ?>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <label for="email_smtp_user" class=" col-md-3"><?php echo app_lang('email_smtp_user'); ?></label>
                        <div class="col-md-9">
                            <?php
                            echo form_input(array(
                                "id" => "email_smtp_user",
                                "name" => "email_smtp_user",
                                "value" => $model_info->email_smtp_user,
                                "class" => "form-control",
                                "placeholder" => app_lang('email_smtp_user'),
                                "data-rule-required" => true,
                                "data-msg-required" => app_lang("field_required"),
                            ));
                            ?>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <label for="email_smtp_pass" class=" col-md-3"><?php echo app_lang('email_smtp_password'); ?></label>
                        <div class="col-md-9">
                            <?php
                            echo form_password(array(
                                "id" => "email_smtp_pass",
                                "name" => "email_smtp_pass",
                                "value" => $model_info->email_smtp_pass ? "******" : "",
                                "class" => "form-control",
                                "placeholder" => app_lang('email_smtp_password'),
                                "data-rule-required" => true,
                                "data-msg-required" => app_lang("field_required"),
                            ));
                            ?>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="row">
                        <label for="email_smtp_port" class=" col-md-3"><?php echo app_lang('email_smtp_port'); ?></label>
                        <div class="col-md-9">
                            <?php
                            echo form_input(array(
                                "id" => "email_smtp_port",
                                "name" => "email_smtp_port",
                                "value" => $model_info->email_smtp_port,
                                "class" => "form-control",
                                "placeholder" => app_lang('email_smtp_port'),
                                "data-rule-required" => true,
                                "data-msg-required" => app_lang("field_required"),
                            ));
                            ?>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="row">
                        <label for="email_smtp_security_type" class=" col-md-3"><?php echo app_lang('security_type'); ?></label>
                        <div class="col-md-9">
                            <?php
                            echo form_dropdown(
                                    "email_smtp_security_type", array(
                                "none" => "-",
                                "tls" => "TLS",
                                "ssl" => "SSL"
                                    ), $model_info->email_smtp_security_type, "class='select2 mini'"
                            );
                            ?>
                        </div>
                    </div>
                </div>

            </div>
            <div class="form-group">
                <div class="row">
                    <label for="send_test_mail_to" class=" col-md-3"><?php echo app_lang('send_test_mail_to'); ?></label>
                    <div class="col-md-9">
                        <?php
                        echo form_input(array(
                            "id" => "send_test_mail_to",
                            "name" => "send_test_mail_to",
                            "class" => "form-control",
                            "placeholder" => "Keep it blank if you are not interested to send test mail",
                        ));
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal-footer">
    <button type="button" class="btn btn-default" data-bs-dismiss="modal"><span data-feather="x" class="icon-16"></span> <?php echo app_lang('close'); ?></button>
    <button type="submit" class="btn btn-primary"><span data-feather='check-circle' class="icon-16"></span> <?php echo app_lang('save'); ?></button>
</div>
<?php echo form_close(); ?>

<script type="text/javascript">
    "use strict";

    $("#mailbox-smtp-settings-form").appForm({
        onSuccess: function (result) {
            appAlert.success(result.message, {duration: 10000});
        }
    });

    $("#mailbox-smtp-settings-form .select2").select2();

    $("#use_smtp").click(function () {
        if ($(this).is(":checked")) {
            $("#smtp_settings").removeClass("hide");
        } else {
            $("#smtp_settings").addClass("hide");
        }
    });

    $("#use_global_email").click(function () {
        if ($(this).is(":checked")) {
            $("#all_smtp_settings").addClass("hide");
        } else {
            $("#all_smtp_settings").removeClass("hide");
        }
    });
</script>
<?php

/* Don't change or add any new config in this file */

namespace Recruitment_management\Config;

use CodeIgniter\Config\BaseConfig;

class Recruitment_management extends BaseConfig {

    public $Recruitment_management_settings_array = array();

}

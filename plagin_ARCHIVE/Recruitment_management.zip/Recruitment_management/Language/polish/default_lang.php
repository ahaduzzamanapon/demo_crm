<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

/* Release 1.0 */

$lang["recruitment"] = "Rekrutacja";
$lang["recruitments"] = "Rekrutacje";
$lang["recruitment_management"] = "Zarządzanie rekrutacją";

$lang["recruitment_education"] = "Edukacja";
$lang["recruitment_work_experience"] = "Doświadczenie zawodowe";

$lang["recruitment_circulars"] = "Biuletyny";
$lang["recruitment_circular_info"] = "Informacje okólnikowe";
$lang["recruitment_circular"] = "Okrągłe";
$lang["recruitment_job_circular"] = "Okres pracy";
$lang["recruitment_job_preview"] = "Podgląd pracy";
$lang["recruitment_job_preview_editor"] = "Edytor podglądu pracy";
$lang["recruitment_candidates"] = "Kandydaci";

$lang["recruitment_add_new_job"] = "Dodaj nową pracę";
$lang["recruitment_edit_job"] = "Edytuj pracę";
$lang["recruitment_delete_job"] = "Usuń pracę";

$lang["recruitment_job_title"] = "Tytuł pracy";
$lang["recruitment_job_position"] = "Stanowisko pracy";
$lang["recruitment_add_job_position"] = "Dodaj stanowisko pracy";
$lang["recruitment_quantity_to_be_required"] = "Ilość do zrekrutowania";
$lang["recruitment_recruiters"] = "Rekruterzy";

$lang["recruitment_mark_as_active"] = "Oznacz jako aktywny";
$lang["recruitment_print_circular"] = "Drukuj okólnik";

$lang["recruitment_settings"] = "Ustawienia rekrutacji";
$lang["recruitment_job_perfix"] = "Prefiks stanowiska";
$lang["recruitment_job_circular_color"] = "Okrągły kolor pracy";
$lang["recruitment_default_job_circular_template"] = "Domyślny szablon cykliczny pracy";
$lang["recruitment_circular_templates"] = "Okrągły szablon pracy";
$lang["recruitment_add_job_circular_template"] = "Dodaj szablon okólnika ofert pracy";
$lang["recruitment_edit_job_circular_template"] = "Edytuj szablon okólnika pracy";
$lang["recruitment_delete_job_circular_template"] = "Usuń szablon okólnika pracy";

$lang["recruitment_resume"] = "Wznów";
$lang["recruitment_upload_your_resume"] = "Prześlij swoje CV";
$lang["recruitment_resume_upload_instruction"] = "Proszę załadować plik pdf lub docx.";
$lang["recruitment_circular_submitted"] = "Dziękujemy za przesłanie swoich danych. Wkrótce skontaktujemy się z Tobą!";
$lang["recruitment_more_circulars"] = "Więcej okólników";

$lang["recruitment_circular_template_inserting_instruction"] = "Utracisz wszystkie niezapisane zmiany przez wstawienie szablonu.";

$lang["recruitment_candidates"] = "Kandydaci";
$lang["recruitment_add_candidates"] = "Dodaj kandydatów";
$lang["recruitment_applied_job"] = "Zastosowana praca";
$lang["recruitment_edit_candidate"] = "Edytuj kandydata";
$lang["recruitment_delete_candidate"] = "Usuń kandydata";
$lang["recruitment_applied_at"] = "Zgłoszono w";
$lang["recruitment_not_reviewed_yet"] = "Jeszcze nie sprawdzone";

$lang["recruitment_stage"] = "Etap";
$lang["recruitment_send_email"] = "Wyślij e-mail";
$lang["recruitment_send_email_to"] = "Wyślij e-mail do";

$lang["recruitment_applicant_details"] = "Szczegóły kandydata";
$lang["recruitment_attachments"] = "Załączniki";

$lang["recruitment_sharing_your_basic_info"] = "Pozwól nam lepiej Cię poznać, dzieląc się podstawowymi informacjami.";
$lang["recruitment_add_a_message_here"] = "Dodaj wiadomość tutaj...";
$lang["recruitment_email_sent_message"] = "E-mail został wysłany!";

$lang["recruitment_application_form"] = "Formularz zgłoszeniowy";
$lang["recruitment_edit_application_form"] = "Edytuj formularz zgłoszeniowy";

$lang["recruitment_hiring_stage"] = "Faza rekrutacji";
$lang["recruitment_hiring_stages"] = "Etapy rekrutacji";
$lang["recruitment_add_hiring_stage"] = "Dodaj etap rekrutacji";
$lang["recruitment_edit_hiring_stage"] = "Edytuj etap zatrudniania";
$lang["recruitment_delete_hiring_stage"] = "Usuń etap zatrudniania";

$lang["recruitment_event_type"] = "Typ wydarzenia";
$lang["recruitment_add_event_type"] = "Dodaj typ wydarzenia";
$lang["recruitment_edit_event_type"] = "Edytuj typ wydarzenia";
$lang["recruitment_delete_event_type"] = "Usuń typ zdarzenia";

$lang["recruitment_job_type"] = "Typ pracy";
$lang["recruitment_add_job_type"] = "Dodaj typ pracy";
$lang["recruitment_edit_job_type"] = "Edytuj typ pracy";
$lang["recruitment_delete_job_type"] = "Usuń typ pracy";

$lang["recruitment_department"] = "Dział";
$lang["recruitment_departments"] = "Departamenty";
$lang["recruitment_add_department"] = "Dodaj dział";
$lang["recruitment_edit_department"] = "Edytuj dział";
$lang["recruitment_delete_department"] = "Usuń dział";

$lang["recruitment_add_location"] = "Dodaj lokalizację";
$lang["recruitment_location"] = "Lokalizacja";
$lang["recruitment_edit_location"] = "Edytuj lokalizację";
$lang["recruitment_delete_location"] = "Usuń lokalizację";

return $lang;

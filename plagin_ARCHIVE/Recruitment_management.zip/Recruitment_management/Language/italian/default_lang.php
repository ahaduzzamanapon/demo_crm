<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

/* Release 1.0 */

$lang["recruitment"] = "Reclutamento";
$lang["recruitments"] = "Reclutamento";
$lang["recruitment_management"] = "Gestione reclutamento";

$lang["recruitment_education"] = "Istruzione";
$lang["recruitment_work_experience"] = "Esperienza lavorativa";

$lang["recruitment_circulars"] = "Circolari";
$lang["recruitment_circular_info"] = "Informazioni circolari";
$lang["recruitment_circular"] = "Circolare";
$lang["recruitment_job_circular"] = "Circolare lavoro";
$lang["recruitment_job_preview"] = "Anteprima lavoro";
$lang["recruitment_job_preview_editor"] = "Editor anteprima lavoro";
$lang["recruitment_candidates"] = "Candidati";

$lang["recruitment_add_new_job"] = "Aggiungi nuovo lavoro";
$lang["recruitment_edit_job"] = "Modifica lavoro";
$lang["recruitment_delete_job"] = "Elimina lavoro";

$lang["recruitment_job_title"] = "Titolo del lavoro";
$lang["recruitment_job_position"] = "Posizione lavorativa";
$lang["recruitment_add_job_position"] = "Aggiungi posizione lavorativa";
$lang["recruitment_quantity_to_be_required"] = "Quantità da reclutare";
$lang["recruitment_recruiters"] = "Reclutatori";

$lang["recruitment_mark_as_active"] = "Segna come attivo";
$lang["recruitment_print_circular"] = "Stampa circolare";

$lang["recruitment_settings"] = "Impostazioni di reclutamento";
$lang["recruitment_job_perfix"] = "Prefisso lavoro";
$lang["recruitment_job_circular_color"] = "Colore circolare lavoro";
$lang["recruitment_default_job_circular_template"] = "Modello circolare di lavoro predefinito";
$lang["recruitment_circular_templates"] = "Modello circolare di lavoro";
$lang["recruitment_add_job_circular_template"] = "Aggiungi modello circolare di lavoro";
$lang["recruitment_edit_job_circular_template"] = "Modifica modello circolare di lavoro";
$lang["recruitment_delete_job_circular_template"] = "Elimina modello circolare di lavoro";

$lang["recruitment_resume"] = "Riprendi";
$lang["recruitment_upload_your_resume"] = "Carica il tuo curriculum";
$lang["recruitment_resume_upload_instruction"] = "Carica un file pdf o docx.";
$lang["recruitment_circular_submitted"] = "Grazie per aver inviato i tuoi dati. Ti contatteremo presto!";
$lang["recruitment_more_circulars"] = "Altre circolari";

$lang["recruitment_circular_template_inserting_instruction"] = "Perse tutte le modifiche non salvate inserendo un modello.";

$lang["recruitment_candidates"] = "Candidati";
$lang["recruitment_add_candidates"] = "Aggiungi candidati";
$lang["recruitment_applied_job"] = "Lavoro applicato";
$lang["recruitment_edit_candidate"] = "Modifica candidato";
$lang["recruitment_delete_candidate"] = "Elimina candidato";
$lang["recruitment_applied_at"] = "Applicato a";
$lang["recruitment_not_reviewed_yet"] = "Non ancora recensito";

$lang["recruitment_stage"] = "Fase";
$lang["recruitment_send_email"] = "Invia email";
$lang["recruitment_send_email_to"] = "Invia email a";

$lang["recruitment_applicant_details"] = "Dettagli richiedente";
$lang["recruitment_attachments"] = "Allegati";

$lang["recruitment_sharing_your_basic_info"] = "Facci conoscere meglio te condividendo le tue informazioni di base.";
$lang["recruitment_add_a_message_here"] = "Aggiungi un messaggio qui...";
$lang["recruitment_email_sent_message"] = "L'email è stata inviata!";

$lang["recruitment_application_form"] = "Modulo di richiesta";
$lang["recruitment_edit_application_form"] = "Modifica modulo di domanda";

$lang["recruitment_hiring_stage"] = "Fase di assunzione";
$lang["recruitment_hiring_stages"] = "Fasi di assunzione";
$lang["recruitment_add_hiring_stage"] = "Aggiungi fase di assunzione";
$lang["recruitment_edit_hiring_stage"] = "Modifica fase di assunzione";
$lang["recruitment_delete_hiring_stage"] = "Elimina fase di assunzione";

$lang["recruitment_event_type"] = "Tipo di evento";
$lang["recruitment_add_event_type"] = "Aggiungi tipo di evento";
$lang["recruitment_edit_event_type"] = "Modifica tipo di evento";
$lang["recruitment_delete_event_type"] = "Elimina tipo di evento";

$lang["recruitment_job_type"] = "Tipo di lavoro";
$lang["recruitment_add_job_type"] = "Aggiungi tipo di lavoro";
$lang["recruitment_edit_job_type"] = "Modifica tipo di lavoro";
$lang["recruitment_delete_job_type"] = "Elimina tipo di lavoro";

$lang["recruitment_department"] = "Reparto";
$lang["recruitment_departments"] = "Dipartimenti";
$lang["recruitment_add_department"] = "Aggiungi reparto";
$lang["recruitment_edit_department"] = "Modifica reparto";
$lang["recruitment_delete_department"] = "Elimina reparto";

$lang["recruitment_add_location"] = "Aggiungi posizione";
$lang["recruitment_location"] = "Posizione";
$lang["recruitment_edit_location"] = "Modifica posizione";
$lang["recruitment_delete_location"] = "Elimina posizione";

return $lang;

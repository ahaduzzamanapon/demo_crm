<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

/* Release 1.0 */

$lang["recruitment"] = "Nábor";
$lang["recruitments"] = "Nábory";
$lang["recruitment_management"] = "Správa náboru";

$lang["recruitment_education"] = "Vzdělávání";
$lang["recruitment_work_experience"] = "Pracovní zkušenosti";

$lang["recruitment_circulars"] = "Oběžníky";
$lang["recruitment_circular_info"] = "Kruhové informace";
$lang["recruitment_circular"] = "Kruhový";
$lang["recruitment_job_circular"] = "Oběžník práce";
$lang["recruitment_job_preview"] = "Náhled úlohy";
$lang["recruitment_job_preview_editor"] = "Editor náhledu úlohy";
$lang["recruitment_candidates"] = "Kandidáti";

$lang["recruitment_add_new_job"] = "Přidat novou práci";
$lang["recruitment_edit_job"] = "Upravit úlohu";
$lang["recruitment_delete_job"] = "Smazat úlohu";

$lang["recruitment_job_title"] = "Název práce";
$lang["recruitment_job_position"] = "Pracovní pozice";
$lang["recruitment_add_job_position"] = "Přidat pracovní pozici";
$lang["recruitment_quantity_to_be_required"] = "Množství k náboru";
$lang["recruitment_recruiters"] = "Náboráři";

$lang["recruitment_mark_as_active"] = "Označit jako aktivní";
$lang["recruitment_print_circular"] = "Tisk oběžníku";

$lang["recruitment_settings"] = "Nastavení náboru";
$lang["recruitment_job_perfix"] = "Předpona úlohy";
$lang["recruitment_job_circular_color"] = "Kruhová barva zakázky";
$lang["recruitment_default_job_circular_template"] = "Výchozí kruhová šablona úlohy";
$lang["recruitment_circular_templates"] = "Kruhová šablona práce";
$lang["recruitment_add_job_circular_template"] = "Přidat kruhovou šablonu úlohy";
$lang["recruitment_edit_job_circular_template"] = "Upravit kruhovou šablonu úlohy";
$lang["recruitment_delete_job_circular_template"] = "Smazat kruhovou šablonu úlohy";

$lang["recruitment_resume"] = "Pokračovat";
$lang["recruitment_upload_your_resume"] = "Nahrajte svůj životopis";
$lang["recruitment_resume_upload_instruction"] = "Nahrajte prosím soubor pdf nebo docx.";
$lang["recruitment_circular_submitted"] = "Děkujeme za odeslání vašich údajů. Brzy vás budeme kontaktovat!";
$lang["recruitment_more_circulars"] = "Další oběžníky";

$lang["recruitment_circular_template_inserting_instruction"] = "Vložením šablony ztratíte všechny neuložené změny.";

$lang["recruitment_candidates"] = "Kandidáti";
$lang["recruitment_add_candidates"] = "Přidat kandidáty";
$lang["recruitment_applied_job"] = "Použitá úloha";
$lang["recruitment_edit_candidate"] = "Upravit kandidáta";
$lang["recruitment_delete_candidate"] = "Smazat kandidáta";
$lang["recruitment_applied_at"] = "Použito v";
$lang["recruitment_not_reviewed_yet"] = "Zatím nezkontrolováno";

$lang["recruitment_stage"] = "Stage";
$lang["recruitment_send_email"] = "Odeslat e-mail";
$lang["recruitment_send_email_to"] = "Odeslat e-mail";

$lang["recruitment_applicant_details"] = "Podrobnosti o žadateli";
$lang["recruitment_attachments"] = "Přílohy";

$lang["recruitment_sharing_your_basic_info"] = "Dejte nám, abychom vás trochu lépe poznali sdílením vašich základních informací.";
$lang["recruitment_add_a_message_here"] = "Sem přidejte zprávu...";
$lang["recruitment_email_sent_message"] = "E-mail byl odeslán!";

$lang["recruitment_application_form"] = "Formulář žádosti";
$lang["recruitment_edit_application_form"] = "Upravit formulář žádosti";

$lang["recruitment_hiring_stage"] = "Fáze náboru";
$lang["recruitment_hiring_stages"] = "Fáze náboru";
$lang["recruitment_add_hiring_stage"] = "Přidat fázi náboru";
$lang["recruitment_edit_hiring_stage"] = "Upravit fázi náboru";
$lang["recruitment_delete_hiring_stage"] = "Smazat fázi náboru";

$lang["recruitment_event_type"] = "Typ události";
$lang["recruitment_add_event_type"] = "Přidat typ události";
$lang["recruitment_edit_event_type"] = "Upravit typ události";
$lang["recruitment_delete_event_type"] = "Smazat typ události";

$lang["recruitment_job_type"] = "Typ úlohy";
$lang["recruitment_add_job_type"] = "Přidat typ úlohy";
$lang["recruitment_edit_job_type"] = "Upravit typ úlohy";
$lang["recruitment_delete_job_type"] = "Smazat typ úlohy";

$lang["recruitment_department"] = "Oddělení";
$lang["recruitment_departments"] = "Oddělení";
$lang["recruitment_add_department"] = "Přidat oddělení";
$lang["recruitment_edit_department"] = "Upravit oddělení";
$lang["recruitment_delete_department"] = "Smazat oddělení";

$lang["recruitment_add_location"] = "Přidat umístění";
$lang["recruitment_location"] = "Umístění";
$lang["recruitment_edit_location"] = "Upravit umístění";
$lang["recruitment_delete_location"] = "Smazat umístění";

return $lang;

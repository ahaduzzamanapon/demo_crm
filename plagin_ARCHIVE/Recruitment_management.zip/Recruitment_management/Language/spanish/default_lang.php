<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

/* Release 1.0 */

$lang["recruitment"] = "Reclutamiento";
$lang["recruitments"] = "Reclutamiento";
$lang["recruitment_management"] = "Gestión de Reclutamiento";

$lang["recruitment_education"] = "Educación";
$lang["recruitment_work_experience"] = "Experiencia laboral";

$lang["recruitment_circulars"] = "Circulares";
$lang["recruitment_circular_info"] = "Información circular";
$lang["recruitment_circular"] = "Circular";
$lang["recruitment_job_circular"] = "Circular de trabajo";
$lang["recruitment_job_preview"] = "Vista previa del trabajo";
$lang["recruitment_job_preview_editor"] = "Editor de vista previa de trabajos";
$lang["recruitment_candidates"] = "Candidatos";

$lang["recruitment_add_new_job"] = "Agregar nuevo trabajo";
$lang["recruitment_edit_job"] = "Editar trabajo";
$lang["recruitment_delete_job"] = "Eliminar trabajo";

$lang["recruitment_job_title"] = "Título del trabajo";
$lang["recruitment_job_position"] = "Puesto de trabajo";
$lang["recruitment_add_job_position"] = "Agregar puesto de trabajo";
$lang["recruitment_quantity_to_be_required"] = "Cantidad a reclutar";
$lang["recruitment_recruiters"] = "Reclutadores";

$lang["recruitment_mark_as_active"] = "Marcar como activo";
$lang["recruitment_print_circular"] = "Imprimir circular";

$lang["recruitment_settings"] = "Configuración de reclutamiento";
$lang["recruitment_job_perfix"] = "Prefijo de trabajo";
$lang["recruitment_job_circular_color"] = "Color circular del trabajo";
$lang["recruitment_default_job_circular_template"] = "Plantilla circular de trabajo predeterminada";
$lang["recruitment_circular_templates"] = "Plantilla circular de trabajo";
$lang["recruitment_add_job_circular_template"] = "Agregar plantilla circular de trabajo";
$lang["recruitment_edit_job_circular_template"] = "Editar plantilla circular de trabajo";
$lang["recruitment_delete_job_circular_template"] = "Eliminar plantilla circular de trabajo";

$lang["recruitment_resume"] = "Resumen";
$lang["recruitment_upload_your_resume"] = "Sube tu currículum";
$lang["recruitment_resume_upload_instruction"] = "Cargue el archivo pdf o docx.";
$lang["recruitment_circular_submitted"] = "Gracias por enviar sus datos. ¡Nos comunicaremos con usted pronto!";
$lang["recruitment_more_circulars"] = "Más circulares";

$lang["recruitment_circular_template_inserting_instruction"] = "Perderá todos los cambios no guardados al insertar una plantilla.";

$lang["recruitment_candidates"] = "Candidatos";
$lang["recruitment_add_candidates"] = "Añadir candidatos";
$lang["recruitment_applied_job"] = "Trabajo solicitado";
$lang["recruitment_edit_candidate"] = "Editar candidato";
$lang["recruitment_delete_candidate"] = "Eliminar candidato";
$lang["recruitment_applied_at"] = "Aplicado en";
$lang["recruitment_not_reviewed_yet"] = "Aún no revisado";

$lang["recruitment_stage"] = "Etapa";
$lang["recruitment_send_email"] = "Enviar correo electrónico";
$lang["recruitment_send_email_to"] = "Enviar correo electrónico a";

$lang["recruitment_applicant_details"] = "Detalles del solicitante";
$lang["recruitment_attachments"] = "Adjuntos";

$lang["recruitment_sharing_your_basic_info"] = "Déjanos conocerte un poco mejor compartiendo tu información básica.";
$lang["recruitment_add_a_message_here"] = "Agregar un mensaje aquí...";
$lang["recruitment_email_sent_message"] = "¡El correo electrónico ha sido enviado!";

$lang["recruitment_application_form"] = "Formulario de solicitud";
$lang["recruitment_edit_application_form"] = "Editar formulario de solicitud";

$lang["recruitment_hiring_stage"] = "Etapa de contratación";
$lang["recruitment_hiring_stages"] = "Etapas de contratación";
$lang["recruitment_add_hiring_stage"] = "Agregar etapa de contratación";
$lang["recruitment_edit_hiring_stage"] = "Editar etapa de contratación";
$lang["recruitment_delete_hiring_stage"] = "Eliminar etapa de contratación";

$lang["recruitment_event_type"] = "Tipo de evento";
$lang["recruitment_add_event_type"] = "Agregar tipo de evento";
$lang["recruitment_edit_event_type"] = "Editar tipo de evento";
$lang["recruitment_delete_event_type"] = "Eliminar tipo de evento";

$lang["recruitment_job_type"] = "Tipo de trabajo";
$lang["recruitment_add_job_type"] = "Agregar tipo de trabajo";
$lang["recruitment_edit_job_type"] = "Editar tipo de trabajo";
$lang["recruitment_delete_job_type"] = "Eliminar tipo de trabajo";

$lang["recruitment_department"] = "Departamento";
$lang["recruitment_departments"] = "Departamentos";
$lang["recruitment_add_department"] = "Agregar departamento";
$lang["recruitment_edit_department"] = "Editar departamento";
$lang["recruitment_delete_department"] = "Eliminar departamento";

$lang["recruitment_add_location"] = "Agregar ubicación";
$lang["recruitment_location"] = "Ubicación";
$lang["recruitment_edit_location"] = "Editar ubicación";
$lang["recruitment_delete_location"] = "Eliminar ubicación";

return $lang;

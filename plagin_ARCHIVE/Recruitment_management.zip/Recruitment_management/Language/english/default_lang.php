<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

/* Release 1.0 */

$lang["recruitment"] = "Recruitment";
$lang["recruitments"] = "Recruitments";
$lang["recruitment_management"] = "Recruitment Management";

$lang["recruitment_education"] = "Education";
$lang["recruitment_work_experience"] = "Work experience";

$lang["recruitment_circulars"] = "Circulars";
$lang["recruitment_circular_info"] = "Circular info";
$lang["recruitment_circular"] = "Circular";
$lang["recruitment_job_circular"] = "Job circular";
$lang["recruitment_job_preview"] = "Job preview";
$lang["recruitment_job_preview_editor"] = "Job preview editor";
$lang["recruitment_candidates"] = "Candidates";

$lang["recruitment_add_new_job"] = "Add new job";
$lang["recruitment_edit_job"] = "Edit job";
$lang["recruitment_delete_job"] = "Delete job";

$lang["recruitment_job_title"] = "Job title";
$lang["recruitment_job_position"] = "Job position";
$lang["recruitment_add_job_position"] = "Add job position";
$lang["recruitment_quantity_to_be_required"] = "Quantity to be recruited";
$lang["recruitment_recruiters"] = "Recruiters";

$lang["recruitment_mark_as_active"] = "Mark as active";
$lang["recruitment_print_circular"] = "Print circular";

$lang["recruitment_settings"] = "Recruitment settings";
$lang["recruitment_job_perfix"] = "Job prefix";
$lang["recruitment_job_circular_color"] = "Job circular color";
$lang["recruitment_default_job_circular_template"] = "Default job circular template";
$lang["recruitment_circular_templates"] = "Job circular template";
$lang["recruitment_add_job_circular_template"] = "Add job circular template";
$lang["recruitment_edit_job_circular_template"] = "Edit job circular template";
$lang["recruitment_delete_job_circular_template"] = "Delete job circular template";

$lang["recruitment_resume"] = "Resume";
$lang["recruitment_upload_your_resume"] = "Upload your resume";
$lang["recruitment_resume_upload_instruction"] = "Please upload pdf or docx file.";
$lang["recruitment_circular_submitted"] = "Thank you for submitting your details. We will contact you soon!";
$lang["recruitment_more_circulars"] = "More circulars";

$lang["recruitment_circular_template_inserting_instruction"] = "You'll lost all unsaved changes by inserting a template.";

$lang["recruitment_candidates"] = "Candidates";
$lang["recruitment_add_candidates"] = "Add candidates";
$lang["recruitment_applied_job"] = "Applied job";
$lang["recruitment_edit_candidate"] = "Edit candidate";
$lang["recruitment_delete_candidate"] = "Delete candidate";
$lang["recruitment_applied_at"] = "Applied at";
$lang["recruitment_not_reviewed_yet"] = "Not reviewed yet";

$lang["recruitment_stage"] = "Stage";
$lang["recruitment_send_email"] = "Send email";
$lang["recruitment_send_email_to"] = "Send email to";

$lang["recruitment_applicant_details"] = "Applicant Details";
$lang["recruitment_attachments"] = "Attachments";

$lang["recruitment_sharing_your_basic_info"] = "Let us get to know you a bit better by sharing your basic info.";
$lang["recruitment_add_a_message_here"] = "Add a message here...";
$lang["recruitment_email_sent_message"] = "The email has been sent!";

$lang["recruitment_application_form"] = "Application form";
$lang["recruitment_edit_application_form"] = "Edit application form";

$lang["recruitment_hiring_stage"] = "Hiring stage";
$lang["recruitment_hiring_stages"] = "Hiring stages";
$lang["recruitment_add_hiring_stage"] = "Add hiring stage";
$lang["recruitment_edit_hiring_stage"] = "Edit hiring stage";
$lang["recruitment_delete_hiring_stage"] = "Delete hiring stage";

$lang["recruitment_event_type"] = "Event type";
$lang["recruitment_add_event_type"] = "Add event type";
$lang["recruitment_edit_event_type"] = "Edit event type";
$lang["recruitment_delete_event_type"] = "Delete event type";

$lang["recruitment_job_type"] = "Job type";
$lang["recruitment_add_job_type"] = "Add job type";
$lang["recruitment_edit_job_type"] = "Edit job type";
$lang["recruitment_delete_job_type"] = "Delete job type";

$lang["recruitment_department"] = "Department";
$lang["recruitment_departments"] = "Departments";
$lang["recruitment_add_department"] = "Add department";
$lang["recruitment_edit_department"] = "Edit department";
$lang["recruitment_delete_department"] = "Delete department";

$lang["recruitment_add_location"] = "Add location";
$lang["recruitment_location"] = "Location";
$lang["recruitment_edit_location"] = "Edit location";
$lang["recruitment_delete_location"] = "Delete location";

return $lang;

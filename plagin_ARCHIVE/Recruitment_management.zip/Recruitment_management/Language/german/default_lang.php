<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

/* Release 1.0 */

$lang["recruitment"] = "Rekrutierung";
$lang["recruitments"] = "Rekrutierungen";
$lang["recruitment_management"] = "Rekrutierungsmanagement";

$lang["recruitment_education"] = "Bildung";
$lang["recruitment_work_experience"] = "Arbeitserfahrung";

$lang["recruitment_circulars"] = "Rundschreiben";
$lang["recruitment_circular_info"] = "Rundschreibeninfo";
$lang["recruitment_circular"] = "Rundschreiben";
$lang["recruitment_job_circular"] = "Job-Rundschreiben";
$lang["recruitment_job_preview"] = "Jobvorschau";
$lang["recruitment_job_preview_editor"] = "Jobvorschau-Editor";
$lang["recruitment_candidates"] = "Kandidaten";

$lang["recruitment_add_new_job"] = "Neuen Job hinzufügen";
$lang["recruitment_edit_job"] = "Job bearbeiten";
$lang["recruitment_delete_job"] = "Stelle löschen";

$lang["recruitment_job_title"] = "Stellenbezeichnung";
$lang["recruitment_job_position"] = "Jobposition";
$lang["recruitment_add_job_position"] = "Jobposition hinzufügen";
$lang["recruitment_quantity_to_be_required"] = "Zu rekrutierende Menge";
$lang["recruitment_recruiters"] = "Rekrutierer";

$lang["recruitment_mark_as_active"] = "Als aktiv markieren";
$lang["recruitment_print_circular"] = "Rundschreiben drucken";

$lang["recruitment_settings"] = "Rekrutierungseinstellungen";
$lang["recruitment_job_perfix"] = "Jobpräfix";
$lang["recruitment_job_circular_color"] = "Farbe des Job-Rundschreibens";
$lang["recruitment_default_job_circular_template"] = "Standardvorlage für Job-Rundschreiben";
$lang["recruitment_circular_templates"] = "Job-Rundschreiben-Vorlage";
$lang["recruitment_add_job_circular_template"] = "Job-Rundschreibenvorlage hinzufügen";
$lang["recruitment_edit_job_circular_template"] = "Job-Rundschreiben-Vorlage bearbeiten";
$lang["recruitment_delete_job_circular_template"] = "Job-Rundschreiben-Vorlage löschen";

$lang["recruitment_resume"] = "Lebenslauf";
$lang["recruitment_upload_your_resume"] = "Laden Sie Ihren Lebenslauf hoch";
$lang["recruitment_resume_upload_instruction"] = "Bitte laden Sie eine pdf- oder docx-Datei hoch.";
$lang["recruitment_circular_submitted"] = "Vielen Dank für die Übermittlung Ihrer Daten. Wir werden Sie bald kontaktieren!";
$lang["recruitment_more_circulars"] = "Weitere Rundschreiben";

$lang["recruitment_circular_template_inserting_instruction"] = "Durch das Einfügen einer Vorlage gehen alle ungespeicherten Änderungen verloren.";

$lang["recruitment_candidates"] = "Kandidaten";
$lang["recruitment_add_candidates"] = "Kandidaten hinzufügen";
$lang["recruitment_applied_job"] = "Beworbener Job";
$lang["recruitment_edit_candidate"] = "Kandidat bearbeiten";
$lang["recruitment_delete_candidate"] = "Kandidat löschen";
$lang["recruitment_applied_at"] = "Beworben bei";
$lang["recruitment_not_reviewed_yet"] = "Noch nicht bewertet";

$lang["recruitment_stage"] = "Stufe";
$lang["recruitment_send_email"] = "E-Mail senden";
$lang["recruitment_send_email_to"] = "E-Mail senden an";

$lang["recruitment_applicant_details"] = "Bewerberdetails";
$lang["recruitment_attachments"] = "Anhänge";

$lang["recruitment_sharing_your_basic_info"] = "Lassen Sie uns Sie ein bisschen besser kennenlernen, indem wir Ihre grundlegenden Informationen teilen.";
$lang["recruitment_add_a_message_here"] = "Hier eine Nachricht hinzufügen...";
$lang["recruitment_email_sent_message"] = "Die E-Mail wurde versendet!";

$lang["recruitment_application_form"] = "Bewerbungsformular";
$lang["recruitment_edit_application_form"] = "Bewerbungsformular bearbeiten";

$lang["recruitment_hiring_stage"] = "Einstellungsphase";
$lang["recruitment_hiring_stages"] = "Einstellungsphasen";
$lang["recruitment_add_hiring_stage"] = "Einstellungsphase hinzufügen";
$lang["recruitment_edit_hiring_stage"] = "Einstellungsphase bearbeiten";
$lang["recruitment_delete_hiring_stage"] = "Einstellungsphase löschen";

$lang["recruitment_event_type"] = "Event-Typ";
$lang["recruitment_add_event_type"] = "Ereignistyp hinzufügen";
$lang["recruitment_edit_event_type"] = "Ereignistyp bearbeiten";
$lang["recruitment_delete_event_type"] = "Ereignistyp löschen";

$lang["recruitment_job_type"] = "Jobtyp";
$lang["recruitment_add_job_type"] = "Jobtyp hinzufügen";
$lang["recruitment_edit_job_type"] = "Jobtyp bearbeiten";
$lang["recruitment_delete_job_type"] = "Jobtyp löschen";

$lang["recruitment_department"] = "Abteilung";
$lang["recruitment_departments"] = "Abteilungen";
$lang["recruitment_add_department"] = "Abteilung hinzufügen";
$lang["recruitment_edit_department"] = "Abteilung bearbeiten";
$lang["recruitment_delete_department"] = "Abteilung löschen";

$lang["recruitment_add_location"] = "Standort hinzufügen";
$lang["recruitment_location"] = "Standort";
$lang["recruitment_edit_location"] = "Standort bearbeiten";
$lang["recruitment_delete_location"] = "Standort löschen";

return $lang;

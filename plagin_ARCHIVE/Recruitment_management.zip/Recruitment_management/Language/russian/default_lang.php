<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

/* Release 1.0 */

$lang["recruitment"] = "Вербовка";
$lang["recruitments"] = "Вербовка";
$lang["recruitment_management"] = "Управление подбором персонала";

$lang["recruitment_education"] = "Образование";
$lang["recruitment_work_experience"] = "Опыт работы";

$lang["recruitment_circulars"] = "Проспекты";
$lang["recruitment_circular_info"] = "Циркулярная информация";
$lang["recruitment_circular"] = "Циркуляр";
$lang["recruitment_job_circular"] = "Проспект вакансий";
$lang["recruitment_job_preview"] = "Предварительный просмотр вакансии";
$lang["recruitment_job_preview_editor"] = "Редактор предварительного просмотра вакансий";
$lang["recruitment_candidates"] = "Кандидаты";

$lang["recruitment_add_new_job"] = "Добавить новую работу";
$lang["recruitment_edit_job"] = "Редактировать задание";
$lang["recruitment_delete_job"] = "Удалить задание";

$lang["recruitment_job_title"] = "Название должности";
$lang["recruitment_job_position"] = "Должность";
$lang["recruitment_add_job_position"] = "Добавить вакансию";
$lang["recruitment_quantity_to_be_required"] = "Количество набираемых";
$lang["recruitment_recruiters"] = "Рекрутеры";

$lang["recruitment_mark_as_active"] = "Отметить как активный";
$lang["recruitment_print_circular"] = "Распечатать проспект";

$lang["recruitment_settings"] = "Настройки рекрутинга";
$lang["recruitment_job_perfix"] = "Префикс вакансии";
$lang["recruitment_job_circular_color"] = "Цвет вакансий";
$lang["recruitment_default_job_circular_template"] = "Шаблон циклического задания по умолчанию";
$lang["recruitment_circular_templates"] = "Шаблон вакансий";
$lang["recruitment_add_job_circular_template"] = "Добавить шаблон рассылки вакансий";
$lang["recruitment_edit_job_circular_template"] = "Редактировать шаблон рассылки вакансий";
$lang["recruitment_delete_job_circular_template"] = "Удалить шаблон рассылки вакансий";

$lang["recruitment_resume"] = "Резюме";
$lang["recruitment_upload_your_resume"] = "Загрузите свое резюме";
$lang["recruitment_resume_upload_instruction"] = "Пожалуйста, загрузите файл pdf или docx.";
$lang["recruitment_circular_submitted"] = "Спасибо за отправку ваших данных. Мы свяжемся с вами в ближайшее время!";
$lang["recruitment_more_circulars"] = "Больше циркуляров";

$lang["recruitment_circular_template_inserting_instruction"] = "Вы потеряете все несохраненные изменения, вставив шаблон.";

$lang["recruitment_candidates"] = "Кандидаты";
$lang["recruitment_add_candidates"] = "Добавить кандидатов";
$lang["recruitment_applied_job"] = "Прикладная работа";
$lang["recruitment_edit_candidate"] = "Редактировать кандидата";
$lang["recruitment_delete_candidate"] = "Удалить кандидата";
$lang["recruitment_applied_at"] = "Применяется в";
$lang["recruitment_not_reviewed_yet"] = "Еще не проверено";

$lang["recruitment_stage"] = "Этап";
$lang["recruitment_send_email"] = "Отправить письмо";
$lang["recruitment_send_email_to"] = "Отправить письмо";

$lang["recruitment_applicant_details"] = "Сведения о кандидате";
$lang["recruitment_attachments"] = "Вложения";

$lang["recruitment_sharing_your_basic_info"] = "Позвольте нам узнать вас поближе, поделившись вашей основной информацией.";
$lang["recruitment_add_a_message_here"] = "Добавьте сюда сообщение...";
$lang["recruitment_email_sent_message"] = "Электронное письмо отправлено!";

$lang["recruitment_application_form"] = "Форма заявки";
$lang["recruitment_edit_application_form"] = "Редактировать форму заявки";

$lang["recruitment_hiring_stage"] = "Этап найма";
$lang["recruitment_hiring_stages"] = "Этапы найма";
$lang["recruitment_add_hiring_stage"] = "Добавить этап найма";
$lang["recruitment_edit_hiring_stage"] = "Изменить этап найма";
$lang["recruitment_delete_hiring_stage"] = "Удалить этап найма";

$lang["recruitment_event_type"] = "Тип события";
$lang["recruitment_add_event_type"] = "Добавить тип события";
$lang["recruitment_edit_event_type"] = "Редактировать тип события";
$lang["recruitment_delete_event_type"] = "Удалить тип события";

$lang["recruitment_job_type"] = "Тип работы";
$lang["recruitment_add_job_type"] = "Добавить тип задания";
$lang["recruitment_edit_job_type"] = "Редактировать тип задания";
$lang["recruitment_delete_job_type"] = "Удалить тип задания";

$lang["recruitment_department"] = "Отдел";
$lang["recruitment_departments"] = "Отделы";
$lang["recruitment_add_department"] = "Добавить отдел";
$lang["recruitment_edit_department"] = "Редактировать отдел";
$lang["recruitment_delete_department"] = "Удалить отдел";

$lang["recruitment_add_location"] = "Добавить местоположение";
$lang["recruitment_location"] = "Местоположение";
$lang["recruitment_edit_location"] = "Редактировать местоположение";
$lang["recruitment_delete_location"] = "Удалить местоположение";

return $lang;

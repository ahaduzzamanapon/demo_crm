<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

/* Release 1.0 */

$lang["recruitment"] = " Πρόσληψη " ;
$lang["recruitments"] = " Προσλήψεις " ;
$lang["recruitment_management"] = "Διαχείριση προσλήψεων";

$lang["recruitment_education"] = "Εκπαίδευση";
$lang["recruitment_work_experience"] = "Εργασιακή εμπειρία";

$lang["recruitment_circulars"] = " Εγκύκλιοι " ;
$lang["recruitment_circular_info"] = "Κυκλικές πληροφορίες";
$lang["recruitment_circular"] = " Εγκύκλιος " ;
$lang["recruitment_job_circular"] = "Εγκύκλιος εργασίας";
$lang["recruitment_job_preview"] = "Προεπισκόπηση εργασίας";
$lang["recruitment_job_preview_editor"] = "Επεξεργαστής προεπισκόπησης εργασίας";
$lang["recruitment_candidates"] = "Υποψήφιοι";

$lang["recruitment_add_new_job"] = "Προσθήκη νέας εργασίας";
$lang["recruitment_edit_job"] = "Επεξεργασία εργασίας";
$lang["recruitment_delete_job"] = "Διαγραφή εργασίας";

$lang["recruitment_job_title"] = "Τίτλος εργασίας";
$lang["recruitment_job_position"] = " Θέση εργασίας " ;
$lang["recruitment_add_job_position"] = "Προσθήκη θέσης εργασίας";
$lang["recruitment_quantity_to_be_required"] = "Ποσότητα προς πρόσληψη";
$lang["recruitment_recruiters"] = " Προσλήψεις " ;

$lang["recruitment_mark_as_active"] = "Επισήμανση ως ενεργού";
$lang["recruitment_print_circular"] = "Εκτύπωση εγκυκλίου";

$lang["recruitment_settings"] = "Ρυθμίσεις πρόσληψης";
$lang["recruitment_job_perfix"] = "Πρόθεμα εργασίας";
$lang["recruitment_job_circular_color"] = "Κυκλικό χρώμα εργασίας";
$lang["recruitment_default_job_circular_template"] = "Προεπιλεγμένο κυκλικό πρότυπο εργασίας";
$lang["recruitment_circular_templates"] = "Κυκλικό πρότυπο εργασίας";
$lang["recruitment_add_job_circular_template"] = "Προσθήκη κυκλικού προτύπου εργασίας";
$lang["recruitment_edit_job_circular_template"] = "Επεξεργασία κυκλικού προτύπου εργασίας";
$lang["recruitment_delete_job_circular_template"] = "Διαγραφή κυκλικού προτύπου εργασίας";

$lang["recruitment_resume"] = "Συνέχιση";
$lang["recruitment_upload_your_resume"] = "Ανεβάστε το βιογραφικό σας";
$lang["recruitment_resume_upload_instruction"] = "Παρακαλώ ανεβάστε αρχείο pdf ή docx.";
$lang["recruitment_circular_submitted"] = "Σας ευχαριστούμε που υποβάλατε τα στοιχεία σας. Θα επικοινωνήσουμε μαζί σας σύντομα!";
$lang["recruitment_more_circulars"] = "Περισσότερες εγκύκλιοι";

$lang["recruitment_circular_template_inserting_instruction"] = "Θα χάσετε όλες τις μη αποθηκευμένες αλλαγές εισάγοντας ένα πρότυπο.";

$lang["recruitment_candidates"] = "Υποψήφιοι";
$lang["recruitment_add_candidates"] = "Προσθήκη υποψηφίων";
$lang["recruitment_applied_job"] = "Εφαρμοσμένη εργασία";
$lang["recruitment_edit_candidate"] = "Επεξεργασία υποψηφίου";
$lang["recruitment_delete_candidate"] = "Διαγραφή υποψηφίου";
$lang["recruitment_applied_at"] = "Εφαρμόστηκε στις";
$lang["recruitment_not_reviewed_yet"] = "Δεν έχει ελεγχθεί ακόμη";

$lang["recruitment_stage"] = "Στάδιο";
$lang["recruitment_send_email"] = "Αποστολή email";
$lang["recruitment_send_email_to"] = "Αποστολή email στο";

$lang["recruitment_applicant_details"] = "Στοιχεία αιτούντος";
$lang["recruitment_attachments"] = " Συνημμένα " ;

$lang["recruitment_sharing_your_basic_info"] = "Επιτρέψτε μας να σας γνωρίσουμε λίγο καλύτερα κοινοποιώντας τις βασικές σας πληροφορίες.";
$lang["recruitment_add_a_message_here"] = "Προσθέστε ένα μήνυμα εδώ...";
$lang["recruitment_email_sent_message"] = "Το email έχει σταλεί!";

$lang["recruitment_application_form"] = "Φόρμα αίτησης";
$lang["recruitment_edit_application_form"] = "Επεξεργασία φόρμας αίτησης";

$lang["recruitment_hiring_stage"] = "Στάδιο πρόσληψης";
$lang["recruitment_hiring_stages"] = "Στάδια πρόσληψης";
$lang["recruitment_add_hiring_stage"] = "Προσθήκη σταδίου πρόσληψης";
$lang["recruitment_edit_hiring_stage"] = "Επεξεργασία σταδίου πρόσληψης";
$lang["recruitment_delete_hiring_stage"] = "Διαγραφή σταδίου πρόσληψης";

$lang["recruitment_event_type"] = "Τύπος εκδήλωσης";
$lang["recruitment_add_event_type"] = "Προσθήκη τύπου συμβάντος";
$lang["recruitment_edit_event_type"] = "Επεξεργασία τύπου συμβάντος";
$lang["recruitment_delete_event_type"] = "Διαγραφή τύπου συμβάντος";

$lang["recruitment_job_type"] = "Τύπος εργασίας";
$lang["recruitment_add_job_type"] = "Προσθήκη τύπου εργασίας";
$lang["recruitment_edit_job_type"] = "Επεξεργασία τύπου εργασίας";
$lang["recruitment_delete_job_type"] = "Διαγραφή τύπου εργασίας";

$lang["recruitment_department"] = "Τμήμα";
$lang["recruitment_departments"] = "Τμήματα";
$lang["recruitment_add_department"] = "Προσθήκη τμήματος";
$lang["recruitment_edit_department"] = "Τμήμα επεξεργασίας";
$lang["recruitment_delete_department"] = "Διαγραφή τμήματος";

$lang["recruitment_add_location"] = "Προσθήκη τοποθεσίας";
$lang["recruitment_location"] = " Τοποθεσία " ;
$lang["recruitment_edit_location"] = "Επεξεργασία τοποθεσίας";
$lang["recruitment_delete_location"] = "Διαγραφή τοποθεσίας";

return $lang;

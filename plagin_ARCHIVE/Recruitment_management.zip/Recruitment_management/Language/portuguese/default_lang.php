<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

/* Release 1.0 */

$lang["recruitment"] = "Recrutamento";
$lang["recruitments"] = "Recrutamentos";
$lang["recruitment_management"] = "Gerenciamento de Recrutamento";

$lang["recruitment_education"] = "Educação";
$lang["recruitment_work_experience"] = "Experiência de trabalho";

$lang["recruitment_circulars"] = "Circulares";
$lang["recruitment_circular_info"] = "Informações circulares";
$lang["recruitment_circular"] = "Circular";
$lang["recruitment_job_circular"] = "Job circular";
$lang["recruitment_job_preview"] = "Visualização do trabalho";
$lang["recruitment_job_preview_editor"] = "Editor de visualização do trabalho";
$lang["recruitment_candidates"] = "Candidatos";

$lang["recruitment_add_new_job"] = "Adicionar novo emprego";
$lang["recruitment_edit_job"] = "Editar vaga";
$lang["recruitment_delete_job"] = "Excluir vaga";

$lang["recruitment_job_title"] = "Título do cargo";
$lang["recruitment_job_position"] = "Cargo de trabalho";
$lang["recruitment_add_job_position"] = "Adicionar cargo";
$lang["recruitment_quantity_to_be_required"] = "Quantidade a ser recrutada";
$lang["recruitment_recruiters"] = "Recrutadores";

$lang["recruitment_mark_as_active"] = "Marcar como ativo";
$lang["recruitment_print_circular"] = "Imprimir circular";

$lang["recruitment_settings"] = "Configurações de recrutamento";
$lang["recruitment_job_perfix"] = "Prefixo do trabalho";
$lang["recruitment_job_circular_color"] = "Cor circular do trabalho";
$lang["recruitment_default_job_circular_template"] = "Modelo circular de trabalho padrão";
$lang["recruitment_circular_templates"] = "Modelo circular de trabalho";
$lang["recruitment_add_job_circular_template"] = "Adicionar modelo circular de trabalho";
$lang["recruitment_edit_job_circular_template"] = "Editar modelo de circular de trabalho";
$lang["recruitment_delete_job_circular_template"] = "Excluir modelo de circular de trabalho";

$lang["recruitment_resume"] = "Retomar";
$lang["recruitment_upload_your_resume"] = "Envie seu currículo";
$lang["recruitment_resume_upload_instruction"] = "Favor enviar arquivo pdf ou docx.";
$lang["recruitment_circular_submitted"] = "Obrigado por enviar seus dados. Entraremos em contato em breve!";
$lang["recruitment_more_circulars"] = "Mais circulares";

$lang["recruitment_circular_template_inserting_instruction"] = "Você perderá todas as alterações não salvas ao inserir um modelo.";

$lang["recruitment_candidates"] = "Candidatos";
$lang["recruitment_add_candidates"] = "Adicionar candidatos";
$lang["recruitment_applied_job"] = "Vaga aplicada";
$lang["recruitment_edit_candidate"] = "Editar candidato";
$lang["recruitment_delete_candidate"] = "Excluir candidato";
$lang["recruitment_applied_at"] = "Aplicado em";
$lang["recruitment_not_reviewed_yet"] = "Ainda não revisada";

$lang["recruitment_stage"] = "Estágio";
$lang["recruitment_send_email"] = "Enviar e-mail";
$lang["recruitment_send_email_to"] = "Enviar email para";

$lang["recruitment_applicant_details"] = "Detalhes do Candidato";
$lang["recruitment_attachments"] = "Anexos";

$lang["recruitment_sharing_your_basic_info"] = "Deixe-nos conhecê-lo um pouco melhor compartilhando suas informações básicas.";
$lang["recruitment_add_a_message_here"] = "Adicione uma mensagem aqui...";
$lang["recruitment_email_sent_message"] = "O email foi enviado!";

$lang["recruitment_application_form"] = "Formulário de inscrição";
$lang["recruitment_edit_application_form"] = "Editar formulário de inscrição";

$lang["recruitment_hiring_stage"] = "Estágio de contratação";
$lang["recruitment_hiring_stages"] = "Estágios de contratação";
$lang["recruitment_add_hiring_stage"] = "Adicionar estágio de contratação";
$lang["recruitment_edit_hiring_stage"] = "Editar estágio de contratação";
$lang["recruitment_delete_hiring_stage"] = "Excluir estágio de contratação";

$lang["recruitment_event_type"] = "Tipo de evento";
$lang["recruitment_add_event_type"] = "Adicionar tipo de evento";
$lang["recruitment_edit_event_type"] = "Editar tipo de evento";
$lang["recruitment_delete_event_type"] = "Excluir tipo de evento";

$lang["recruitment_job_type"] = "Tipo de trabalho";
$lang["recruitment_add_job_type"] = "Adicionar tipo de trabalho";
$lang["recruitment_edit_job_type"] = "Editar tipo de trabalho";
$lang["recruitment_delete_job_type"] = "Excluir tipo de trabalho";

$lang["recruitment_department"] = "Departamento";
$lang["recruitment_departments"] = "Departamentos";
$lang["recruitment_add_department"] = "Adicionar departamento";
$lang["recruitment_edit_department"] = "Editar departamento";
$lang["recruitment_delete_department"] = "Excluir departamento";

$lang["recruitment_add_location"] = "Adicionar local";
$lang["recruitment_location"] = "Localização";
$lang["recruitment_edit_location"] = "Editar local";
$lang["recruitment_delete_location"] = "Excluir local";

return $lang;

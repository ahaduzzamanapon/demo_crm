<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

/* Release 1.0 */

$lang["recruitment"] = "Tuyển dụng";
$lang["recruitments"] = "Tuyển dụng";
$lang["recruitment_management "] =" Quản lý Tuyển dụng ";

$lang["recruitment_education"] = "Học vấn";
$lang["recruitment_work_experience"] = "Kinh nghiệm làm việc";

$lang["recruitment_circulars"] = "Thông tư";
$lang["recruitment_circular_info"] = "Thông tin về vòng tròn";
$lang["recruitment_circular"] = "Thông tư";
$lang["recruitment_job_circular"] = "Thông báo tuyển dụng";
$lang["recruitment_job_preview"] = "Xem trước công việc";
$lang["recruitment_job_preview_editor"] = "Trình chỉnh sửa bản xem trước công việc";
$lang["recruitment_candidates"] = "Ứng viên";

$lang["recruitment_add_new_job"] = "Thêm công việc mới";
$lang["recruitment_edit_job"] = "Chỉnh sửa công việc";
$lang["recruitment_delete_job"] = "Xóa công việc";

$lang["recruitment_job_title"] = "Tiêu đề";
$lang["recruitment_job_position"] = "Vị trí công việc";
$lang["recruitment_add_job_position"] = "Thêm vị trí công việc";
$lang["recruitment_quantity_to_be_required"] = "Số lượng cần tuyển";
$lang["recruitment_recruiters"] = "Người tuyển dụng";

$lang["recruitment_mark_as_active"] = "Đánh dấu là hoạt động";
$lang["recruitment_print_circular"] = "In vòng tròn";

$lang["recruitment_settings"] = "Cài đặt tuyển dụng";
$lang["recruitment_job_perfix"] = "Tiền tố công việc";
$lang["recruitment_job_circular_color"] = "Màu vòng tròn công việc";
$lang["recruitment_default_job_circular_template"] = "Mẫu vòng tròn việc làm mặc định";
$lang["recruitment_circular_templates"] = "Mẫu vòng tròn việc làm";
$lang["recruitment_add_job_circular_template"] = "Thêm mẫu vòng tròn việc làm";
$lang["recruitment_edit_job_circular_template"] = "Chỉnh sửa mẫu vòng tròn việc làm";
$lang["recruitment_delete_job_circular_template"] = "Xóa mẫu vòng tròn việc làm";

$lang["recruitment_resume"] = "Sơ yếu lý lịch";
$lang["recruitment_upload_your_resume"] = "Tải lên sơ yếu lý lịch của bạn";
$lang["recruitment_resume_upload_instruction"] = "Vui lòng tải lên tệp pdf hoặc docx.";
$lang["recruitment_circular_submitted"] = "Cảm ơn bạn đã gửi thông tin chi tiết của bạn. Chúng tôi sẽ liên hệ lại với bạn sớm!";
$lang["recruitment_more_circulars"] = "Thông tư khác";

$lang["recruitment_circular_template_inserting_instruction"] = "Bạn sẽ mất tất cả các thay đổi chưa được lưu khi chèn mẫu.";

$lang["recruitment_candidates"] = "Ứng viên";
$lang["recruitment_add_candidates"] = "Thêm ứng viên";
$lang["recruitment_applied_job"] = "Công việc đã ứng tuyển";
$lang["recruitment_edit_candidate"] = "Chỉnh sửa ứng viên";
$lang["recruitment_delete_candidate"] = "Xóa ứng viên";
$lang["recruitment_applied_at"] = "Ứng tuyển tại";
$lang["recruitment_not_reviewed_yet"] = "Chưa được xem xét";

$lang["recruitment_stage"] = "Giai đoạn";
$lang["recruitment_send_email"] = "Gửi email";
$lang["recruitment_send_email_to"] = "Gửi email tới";

$lang["recruitment_applicant_details"] = "Chi tiết về Ứng viên";
$lang["recruitment_attachments "] =" Phần đính kèm ";

$lang["recruitment_sharing_your_basic_info"] = "Hãy để chúng tôi hiểu rõ hơn về bạn bằng cách chia sẻ thông tin cơ bản của bạn.";
$lang["recruitment_add_a_message_here"] = "Thêm thông báo vào đây ...";
$lang["recruitment_email_sent_message"] = "Email đã được gửi!";

$lang["recruitment_application_form"] = "Mẫu đăng ký";
$lang["recruitment_edit_application_form"] = "Chỉnh sửa đơn đăng ký";

$lang["recruitment_hiring_stage"] = "Giai đoạn tuyển dụng";
$lang["recruitment_hiring_stages"] = "Các giai đoạn tuyển dụng";
$lang["recruitment_add_hiring_stage"] = "Thêm giai đoạn tuyển dụng";
$lang["recruitment_edit_hiring_stage"] = "Chỉnh sửa giai đoạn tuyển dụng";
$lang["recruitment_delete_hiring_stage"] = "Xóa giai đoạn tuyển dụng";

$lang["recruitment_event_type"] = "Loại sự kiện";
$lang["recruitment_add_event_type"] = "Thêm loại sự kiện";
$lang["recruitment_edit_event_type"] = "Chỉnh sửa loại sự kiện";
$lang["recruitment_delete_event_type"] = "Xóa loại sự kiện";

$lang["recruitment_job_type"] = "Loại công việc";
$lang["recruitment_add_job_type"] = "Thêm loại công việc";
$lang["recruitment_edit_job_type"] = "Chỉnh sửa loại công việc";
$lang["recruitment_delete_job_type"] = "Xóa loại công việc";

$lang["recruitment_department"] = "Phòng ban";
$lang["recruitment_departments"] = "Phòng ban";
$lang["recruitment_add_department"] = "Thêm bộ phận";
$lang["recruitment_edit_department"] = "Chỉnh sửa bộ phận";
$lang["recruitment_delete_department"] = "Xóa bộ phận";

$lang["recruitment_add_location"] = "Thêm vị trí";
$lang["recruitment_location"] = "Vị trí";
$lang["recruitment_edit_location"] = "Chỉnh sửa vị trí";
$lang["recruitment_delete_location"] = "Xóa vị trí";

return $lang;

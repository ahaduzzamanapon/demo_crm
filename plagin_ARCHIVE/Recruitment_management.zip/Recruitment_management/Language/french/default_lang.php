<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

/* Release 1.0 */

$lang["recruitment"] = "Recrutement";
$lang["recruitments"] = "Recrutements";
$lang["recruitment_management"] = "Gestion du recrutement";

$lang["recruitment_education"] = "Éducation";
$lang["recruitment_work_experience"] = "Expérience professionnelle";

$lang["recruitment_circulars"] = "Circulaires";
$lang["recruitment_circular_info"] = "Information circulaire";
$lang["recruitment_circular"] = "Circulaire";
$lang["recruitment_job_circular"] = "Circulaire d'emploi";
$lang["recruitment_job_preview"] = "Aperçu du poste";
$lang["recruitment_job_preview_editor"] = "Éditeur d'aperçu d'emploi";
$lang["recruitment_candidates"] = "Candidats";

$lang["recruitment_add_new_job"] = "Ajouter un nouvel emploi";
$lang["recruitment_edit_job"] = "Modifier le poste";
$lang["recruitment_delete_job"] = "Supprimer le poste";

$lang["recruitment_job_title"] = "Titre du poste";
$lang["recruitment_job_position"] = "Poste";
$lang["recruitment_add_job_position"] = "Ajouter un poste";
$lang["recruitment_quantity_to_be_required"] = "Quantité à recruter";
$lang["recruitment_recruiters"] = "Recruteurs";

$lang["recruitment_mark_as_active"] = "Marquer comme actif";
$lang["recruitment_print_circular"] = "Imprimer la circulaire";

$lang["recruitment_settings"] = "Paramètres de recrutement";
$lang["recruitment_job_perfix"] = "Préfixe du poste";
$lang["recruitment_job_circular_color"] = "Couleur circulaire de l'emploi";
$lang["recruitment_default_job_circular_template"] = "Modèle de circulaire d'emploi par défaut";
$lang["recruitment_circular_templates"] = "Modèle de circulaire d'emploi";
$lang["recruitment_add_job_circular_template"] = "Ajouter un modèle de circulaire d'emploi";
$lang["recruitment_edit_job_circular_template"] = "Modifier le modèle de circulaire d'emploi";
$lang["recruitment_delete_job_circular_template"] = "Supprimer le modèle de circulaire d'emploi";

$lang["recruitment_resume"] = "Reprendre";
$lang["recruitment_upload_your_resume"] = "Téléchargez votre CV";
$lang["recruitment_resume_upload_instruction"] = "Veuillez télécharger un fichier pdf ou docx.";
$lang["recruitment_circular_submitted"] = "Merci d'avoir soumis vos coordonnées. Nous vous contacterons bientôt !";
$lang["recruitment_more_circulars"] = "Plus de circulaires";

$lang["recruitment_circular_template_inserting_instruction"] = "Vous perdrez toutes les modifications non enregistrées en insérant un modèle.";

$lang["recruitment_candidates"] = "Candidats";
$lang["recruitment_add_candidates"] = "Ajouter des candidats";
$lang["recruitment_applied_job"] = "Emploi postulé";
$lang["recruitment_edit_candidate"] = "Modifier le candidat";
$lang["recruitment_delete_candidate"] = "Supprimer le candidat";
$lang["recruitment_applied_at"] = "A postulé à";
$lang["recruitment_not_reviewed_yet"] = "Pas encore examiné";

$lang["recruitment_stage"] = "Étape";
$lang["recruitment_send_email"] = "Envoyer un e-mail";
$lang["recruitment_send_email_to"] = "Envoyer un e-mail à";

$lang["recruitment_applicant_details"] = "Détails du candidat";
$lang["recruitment_attachments"] = "Pièces jointes";

$lang["recruitment_sharing_your_basic_info"] = "Permettez-nous de mieux vous connaître en partageant vos informations de base.";
$lang["recruitment_add_a_message_here"] = "Ajouter un message ici...";
$lang["recruitment_email_sent_message"] = "L'email a été envoyé !";

$lang["recruitment_application_form"] = "Formulaire de candidature";
$lang["recruitment_edit_application_form"] = "Modifier le formulaire de candidature";

$lang["recruitment_hiring_stage"] = "Etape d'embauche";
$lang["recruitment_hiring_stages"] = "Etapes d'embauche";
$lang["recruitment_add_hiring_stage"] = "Ajouter une étape de recrutement";
$lang["recruitment_edit_hiring_stage"] = "Modifier l'étape d'embauche";
$lang["recruitment_delete_hiring_stage"] = "Supprimer l'étape d'embauche";

$lang["recruitment_event_type"] = "Type d'événement";
$lang["recruitment_add_event_type"] = "Ajouter un type d'événement";
$lang["recruitment_edit_event_type"] = "Modifier le type d'événement";
$lang["recruitment_delete_event_type"] = "Supprimer le type d'événement";

$lang["recruitment_job_type"] = "Type de poste";
$lang["recruitment_add_job_type"] = "Ajouter un type de poste";
$lang["recruitment_edit_job_type"] = "Modifier le type de poste";
$lang["recruitment_delete_job_type"] = "Supprimer le type de poste";

$lang["recruitment_department"] = "Département";
$lang["recruitment_departments"] = "Départements";
$lang["recruitment_add_department"] = "Ajouter un département";
$lang["recruitment_edit_department"] = "Modifier le département";
$lang["recruitment_delete_department"] = "Supprimer le département";

$lang["recruitment_add_location"] = "Ajouter un lieu";
$lang["recruitment_location"] = "Emplacement";
$lang["recruitment_edit_location"] = "Modifier l'emplacement";
$lang["recruitment_delete_location"] = "Supprimer l'emplacement";

return $lang;

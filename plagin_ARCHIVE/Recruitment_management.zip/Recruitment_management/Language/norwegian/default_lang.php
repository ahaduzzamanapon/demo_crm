<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

/* Release 1.0 */

$lang["recruitment"] = "Rekruttering";
$lang["recruitments"] = "Rekrutteringer";
$lang["recruitment_management"] = "Rekrutteringsadministrasjon";

$lang["recruitment_education"] = "Utdanning";
$lang["recruitment_work_experience"] = "Arbeidserfaring";

$lang["recruitment_circulars"] = "Rundskriv";
$lang["recruitment_circular_info"] = "Sirkulærinformasjon";
$lang["recruitment_circular"] = "Sirkulær";
$lang["recruitment_job_circular"] = "Jobbsirkulær";
$lang["recruitment_job_preview"] = "Forhåndsvisning av jobb";
$lang["recruitment_job_preview_editor"] = "Redigering av jobbforhåndsvisning";
$lang["recruitment_candidates"] = "Kandidater";

$lang["recruitment_add_new_job"] = "Legg til ny jobb";
$lang["recruitment_edit_job"] = "Rediger jobb";
$lang["recruitment_delete_job"] = "Slett jobb";

$lang["recruitment_job_title"] = "Jobbtittel";
$lang["recruitment_job_position"] = "Jobbstilling";
$lang["recruitment_add_job_position"] = "Legg til stilling";
$lang["recruitment_quantity_to_be_required"] = "Antall som skal rekrutteres";
$lang["recruitment_recruiters"] = "Rekrutterere";

$lang["recruitment_mark_as_active"] = "Merk som aktiv";
$lang["recruitment_print_circular"] = "Skriv ut rundskriv";

$lang["recruitment_settings"] = "Rekrutteringsinnstillinger";
$lang["recruitment_job_perfix"] = "Jobbprefiks";
$lang["recruitment_job_circular_color"] = "Jobb sirkulær farge";
$lang["recruitment_default_job_circular_template"] = "Standard sirkulær mal for jobb";
$lang["recruitment_circular_templates"] = "Sirkulær jobbmal";
$lang["recruitment_add_job_circular_template"] = "Legg til jobbsirkulær mal";
$lang["recruitment_edit_job_circular_template"] = "Rediger jobbsirkulær mal";
$lang["recruitment_delete_job_circular_template"] = "Slett jobbsirkulær mal";

$lang["recruitment_resume"] = "Fortsett";
$lang["recruitment_upload_your_resume"] = "Last opp din CV";
$lang["recruitment_resume_upload_instruction"] = "Vennligst last opp pdf- eller docx-fil.";
$lang["recruitment_circular_submitted"] = "Takk for at du sendte inn dine opplysninger. Vi kontakter deg snart!";
$lang["recruitment_more_circulars"] = "Flere rundskriv";

$lang["recruitment_circular_template_inserting_instruction"] = "Du vil miste alle ulagrede endringer ved å sette inn en mal.";

$lang["recruitment_candidates"] = "Kandidater";
$lang["recruitment_add_candidates"] = "Legg til kandidater";
$lang["recruitment_applied_job"] = "Søkt jobb";
$lang["recruitment_edit_candidate"] = "Rediger kandidat";
$lang["recruitment_delete_candidate"] = "Slett kandidat";
$lang["recruitment_applied_at"] = "Søkt på";
$lang["recruitment_not_reviewed_yet"] = "Ikke gjennomgått ennå";

$lang["recruitment_stage"] = "Stage";
$lang["recruitment_send_email"] = "Send e-post";
$lang["recruitment_send_email_to"] = "Send e-post til";

$lang["recruitment_applicant_details"] = "Søkerdetaljer";
$lang["recruitment_attachments"] = "Vedlegg";

$lang["recruitment_sharing_your_basic_info"] = "La oss bli litt bedre kjent med deg ved å dele din grunnleggende informasjon.";
$lang["recruitment_add_a_message_here"] = "Legg til en melding her...";
$lang["recruitment_email_sent_message"] = "E-posten er sendt!";

$lang["recruitment_application_form"] = "Søknadsskjema";
$lang["recruitment_edit_application_form"] = "Rediger søknadsskjema";

$lang["recruitment_hiring_stage"] = "Ansettelsesstadiet";
$lang["recruitment_hiring_stages"] = "Ansettelsesstadier";
$lang["recruitment_add_hiring_stage"] = "Legg til ansettelsesfase";
$lang["recruitment_edit_hiring_stage"] = "Rediger ansettelsesstadiet";
$lang["recruitment_delete_hiring_stage"] = "Slett ansettelsesstadiet";

$lang["recruitment_event_type"] = "Hendelsestype";
$lang["recruitment_add_event_type"] = "Legg til hendelsestype";
$lang["recruitment_edit_event_type"] = "Rediger hendelsestype";
$lang["recruitment_delete_event_type"] = "Slett hendelsestype";

$lang["recruitment_job_type"] = "Jobbtype";
$lang["recruitment_add_job_type"] = "Legg til jobbtype";
$lang["recruitment_edit_job_type"] = "Rediger jobbtype";
$lang["recruitment_delete_job_type"] = "Slett jobbtype";

$lang["recruitment_department"] = "Avdeling";
$lang["recruitment_departments"] = "Avdelinger";
$lang["recruitment_add_department"] = "Legg til avdeling";
$lang["recruitment_edit_department"] = "Rediger avdeling";
$lang["recruitment_delete_department"] = "Slett avdeling";

$lang["recruitment_add_location"] = "Legg til plassering";
$lang["recruitment_location"] = "Plassering";
$lang["recruitment_edit_location"] = "Rediger plassering";
$lang["recruitment_delete_location"] = "Slett plassering";

return $lang;

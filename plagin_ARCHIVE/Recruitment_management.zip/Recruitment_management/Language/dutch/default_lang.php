<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

/* Release 1.0 */

$lang["recruitment"] = "Werving";
$lang["recruitments"] = "Rekruteringen";
$lang["recruitment_management"] = "Recruitmentbeheer";

$lang["recruitment_education"] = "Onderwijs";
$lang["recruitment_work_experience"] = "Werkervaring";

$lang["recruitment_circulars"] = "Cirkels";
$lang["recruitment_circular_info"] = "Circulaire info";
$lang["recruitment_circular"] = "Circulair";
$lang["recruitment_job_circular"] = "Circulaire vacature";
$lang["recruitment_job_preview"] = "Vacaturevoorbeeld";
$lang["recruitment_job_preview_editor"] = "Vacaturevoorbeeld-editor";
$lang["recruitment_candidates"] = "Kandidaten";

$lang["recruitment_add_new_job"] = "Nieuwe baan toevoegen";
$lang["recruitment_edit_job"] = "Vacature bewerken";
$lang["recruitment_delete_job"] = "Vacature verwijderen";

$lang["recruitment_job_title"] = "Functietitel";
$lang["recruitment_job_position"] = "Vacature";
$lang["recruitment_add_job_position"] = "Vacature toevoegen";
$lang["recruitment_quantity_to_be_required"] = "Aan te werven hoeveelheid";
$lang["recruitment_recruiters"] = "Recruiters";

$lang["recruitment_mark_as_active"] = "Markeer als actief";
$lang["recruitment_print_circular"] = "Circulair afdrukken";

$lang["recruitment_settings"] = "Recruitment instellingen";
$lang["recruitment_job_perfix"] = "Vacaturevoorvoegsel";
$lang["recruitment_job_circular_color"] = "Taak cirkelvormige kleur";
$lang["recruitment_default_job_circular_template"] = "Standaard circulaire vacaturesjabloon";
$lang["recruitment_circular_templates"] = "Circulair vacaturesjabloon";
$lang["recruitment_add_job_circular_template"] = "Circulair sjabloon voor vacatures toevoegen";
$lang["recruitment_edit_job_circular_template"] = "Bewerk circulaire sjabloon voor vacatures";
$lang["recruitment_delete_job_circular_template"] = "Circulair sjabloon voor vacature verwijderen";

$lang["recruitment_resume"] = "Hervatten";
$lang["recruitment_upload_your_resume"] = "Upload je cv";
$lang["recruitment_resume_upload_instruction"] = "Upload een pdf- of docx-bestand.";
$lang["recruitment_circular_submitted"] = "Bedankt voor het invullen van uw gegevens. We nemen spoedig contact met u op!";
$lang["recruitment_more_circulars"] = "Meer circulaires";

$lang["recruitment_circular_template_inserting_instruction"] = "Je verliest alle niet-opgeslagen wijzigingen door een sjabloon in te voegen.";

$lang["recruitment_candidates"] = "Kandidaten";
$lang["recruitment_add_candidates"] = "Kandidaten toevoegen";
$lang["recruitment_applied_job"] = "Gesolliciteerde vacature";
$lang["recruitment_edit_candidate"] = "Kandidaat bewerken";
$lang["recruitment_delete_candidate"] = "Kandidaat verwijderen";
$lang["recruitment_applied_at"] = "Gesolliciteerd om";
$lang["recruitment_not_reviewed_yet"] = "Nog niet beoordeeld";

$lang["recruitment_stage"] = "Stage";
$lang["recruitment_send_email"] = "E-mail verzenden";
$lang["recruitment_send_email_to"] = "Stuur een e-mail naar";

$lang["recruitment_applicant_details"] = "Gegevens sollicitant";
$lang["recruitment_attachments"] = "Bijlagen";

$lang["recruitment_sharing_your_basic_info"] = "Laat ons je een beetje beter leren kennen door je basisinformatie te delen.";
$lang["recruitment_add_a_message_here"] = "Voeg hier een bericht toe...";
$lang["recruitment_email_sent_message"] = "De e-mail is verzonden!";

$lang["recruitment_application_form"] = "Aanvraagformulier";
$lang["recruitment_edit_application_form"] = "Aanvraagformulier bewerken";

$lang["recruitment_hiring_stage"] = "Aanwervingsfase";
$lang["recruitment_hiring_stages"] = "Aanwervingsfasen";
$lang["recruitment_add_hiring_stage"] = "Voeg aanwervingsfase toe";
$lang["recruitment_edit_hiring_stage"] = "Bewerk aanstellingsfase";
$lang["recruitment_delete_hiring_stage"] = "Verwijder aanwervingsfase";

$lang["recruitment_event_type"] = "Evenementtype";
$lang["recruitment_add_event_type"] = "Voeg gebeurtenistype toe";
$lang["recruitment_edit_event_type"] = "Bewerk type evenement";
$lang["recruitment_delete_event_type"] = "Verwijder gebeurtenistype";

$lang["recruitment_job_type"] = "Vacaturetype";
$lang["recruitment_add_job_type"] = "Vacaturetype toevoegen";
$lang["recruitment_edit_job_type"] = "Vacaturetype bewerken";
$lang["recruitment_delete_job_type"] = "Vacaturetype verwijderen";

$lang["recruitment_department"] = "Afdeling";
$lang["recruitment_departments"] = "Afdelingen";
$lang["recruitment_add_department"] = "Afdeling toevoegen";
$lang["recruitment_edit_department"] = "Afdeling bewerken";
$lang["recruitment_delete_department"] = "Verwijder afdeling";

$lang["recruitment_add_location"] = "Locatie toevoegen";
$lang["recruitment_location"] = "Locatie";
$lang["recruitment_edit_location"] = "Locatie bewerken";
$lang["recruitment_delete_location"] = "Locatie verwijderen";

return $lang;

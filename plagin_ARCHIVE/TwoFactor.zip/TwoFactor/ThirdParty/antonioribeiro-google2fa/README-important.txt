# Removed ":" from the Authenticator title
...\vendor\pragmarx\google2fa\src\Support\QRCode.php

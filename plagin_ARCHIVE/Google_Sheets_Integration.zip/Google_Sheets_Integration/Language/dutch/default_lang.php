<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["google_sheets_integration"] = "Google Spreadsheets-integratie";
$lang["google_sheets"] = "Google Spreadsheets";
$lang["google_sheets_integration_integrate_google_sheets"] = "Google Spreadsheets integreren";
$lang["google_sheets_integration_client_can_access_google_sheets"] = "Klant heeft toegang tot Google Spreadsheets?";
$lang["google_sheets_integration_add_spreadsheet"] = "Spreadsheet toevoegen";
$lang["google_sheets_integration_edit_spreadsheet"] = "Spreadsheet bewerken";
$lang["google_sheets_integration_delete_spreadsheet"] = "Verwijder spreadsheet";
$lang["google_sheets_integration_all_client_contacts"] = "Alle klantcontacten";
$lang["google_sheets_integration_choose_client_contacts"] = "Kies klantcontacten";

$lang["google_sheets_integration_can_manage_google_sheets"] = "Kan Google Spreadsheets beheren?";

return $lang;

<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["google_sheets_integration"] = "Integrazione di Fogli Google";
$lang["google_sheets"] = "Fogli Google";
$lang["google_sheets_integration_integrate_google_sheets"] = "Integra Fogli Google";
$lang["google_sheets_integration_client_can_access_google_sheets"] = "Il cliente può accedere a Fogli Google?";
$lang["google_sheets_integration_add_spreadsheet"] = "Aggiungi foglio di calcolo";
$lang["google_sheets_integration_edit_spreadsheet"] = "Modifica foglio di calcolo";
$lang["google_sheets_integration_delete_spreadsheet"] = "Elimina foglio di calcolo";
$lang["google_sheets_integration_all_client_contacts"] = "Tutti i contatti del cliente";
$lang["google_sheets_integration_choose_client_contacts"] = "Scegli i contatti del cliente";

$lang["google_sheets_integration_can_manage_google_sheets"] = "Può gestire Fogli Google?";

return $lang;

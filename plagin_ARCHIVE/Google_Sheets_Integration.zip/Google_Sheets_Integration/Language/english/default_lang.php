<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["google_sheets_integration"] = "Google Sheets Integration";
$lang["google_sheets"] = "Google Sheets";
$lang["google_sheets_integration_integrate_google_sheets"] = "Integrate Google Sheets";
$lang["google_sheets_integration_client_can_access_google_sheets"] = "Client can access Google Sheets?";
$lang["google_sheets_integration_add_spreadsheet"] = "Add spreadsheet";
$lang["google_sheets_integration_edit_spreadsheet"] = "Edit spreadsheet";
$lang["google_sheets_integration_delete_spreadsheet"] = "Delete spreadsheet";
$lang["google_sheets_integration_all_client_contacts"] = "All client contacts";
$lang["google_sheets_integration_choose_client_contacts"] = "Choose client contacts";

$lang["google_sheets_integration_can_manage_google_sheets"] = "Can manage Google Sheets?";

return $lang;

<?php //copy from default_lang.php file and update

$lang["google_sheets_integration_example"] = "Example";

return $lang;
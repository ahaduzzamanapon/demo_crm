<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["google_sheets_integration"] = "Integrace Tabulek Google";
$lang["google_sheets"] = "Tabulky Google";
$lang["google_sheets_integration_integrate_google_sheets"] = "Integrovat Tabulky Google";
$lang["google_sheets_integration_client_can_access_google_sheets"] = "Klient má přístup k Tabulkám Google?";
$lang["google_sheets_integration_add_spreadsheet"] = "Přidat tabulku";
$lang["google_sheets_integration_edit_spreadsheet"] = "Upravit tabulku";
$lang["google_sheets_integration_delete_spreadsheet"] = "Smazat tabulku";
$lang["google_sheets_integration_all_client_contacts"] = "Všechny klientské kontakty";
$lang["google_sheets_integration_choose_client_contacts"] = "Vyberte kontakty klienta";

$lang["google_sheets_integration_can_manage_google_sheets"] = "Umíte spravovat Tabulky Google?";

return $lang;

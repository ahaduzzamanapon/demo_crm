<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["google_sheets_integration"] = "Google Sheets-Integration";
$lang["google_sheets"] = "Google Sheets";
$lang["google_sheets_integration_integrate_google_sheets"] = "Google Sheets integrieren";
$lang["google_sheets_integration_client_can_access_google_sheets"] = "Der Kunde kann auf Google Sheets zugreifen?";
$lang["google_sheets_integration_add_spreadsheet"] = "Tabelle hinzufügen";
$lang["google_sheets_integration_edit_spreadsheet"] = "Tabelle bearbeiten";
$lang["google_sheets_integration_delete_spreadsheet"] = "Tabelle löschen";
$lang["google_sheets_integration_all_client_contacts"] = "Alle Kundenkontakte";
$lang["google_sheets_integration_choose_client_contacts"] = "Kundenkontakte auswählen";

$lang["google_sheets_integration_can_manage_google_sheets"] = "Kann Google Sheets verwalten?";

return $lang;

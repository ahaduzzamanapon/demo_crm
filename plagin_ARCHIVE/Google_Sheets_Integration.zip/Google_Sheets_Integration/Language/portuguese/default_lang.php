<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["google_sheets_integration"] = "Integração com Planilhas Google";
$lang["google_sheets"] = "Planilhas Google";
$lang["google_sheets_integration_integrate_google_sheets"] = "Integrar Planilhas Google";
$lang["google_sheets_integration_client_can_access_google_sheets"] = "O cliente pode acessar o Planilhas Google?";
$lang["google_sheets_integration_add_spreadsheet"] = "Adicionar planilha";
$lang["google_sheets_integration_edit_spreadsheet"] = "Editar planilha";
$lang["google_sheets_integration_delete_spreadsheet"] = "Excluir planilha";
$lang["google_sheets_integration_all_client_contacts"] = "Todos os contatos do cliente";
$lang["google_sheets_integration_choose_client_contacts"] = "Escolha os contatos do cliente";

$lang["google_sheets_integration_can_manage_google_sheets"] = "É possível gerenciar o Planilhas Google?";

return $lang;

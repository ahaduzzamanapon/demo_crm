<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["google_sheets_integration"] = "Integracja z Arkuszami Google";
$lang["google_sheets"] = "Arkusze Google";
$lang["google_sheets_integration_integrate_google_sheets"] = "Zintegruj Arkusze Google";
$lang["google_sheets_integration_client_can_access_google_sheets"] = "Klient może uzyskać dostęp do Arkuszy Google?";
$lang["google_sheets_integration_add_spreadsheet"] = "Dodaj arkusz kalkulacyjny";
$lang["google_sheets_integration_edit_spreadsheet"] = "Edytuj arkusz kalkulacyjny";
$lang["google_sheets_integration_delete_spreadsheet"] = "Usuń arkusz kalkulacyjny";
$lang["google_sheets_integration_all_client_contacts"] = "Wszystkie kontakty klientów";
$lang["google_sheets_integration_choose_client_contacts"] = "Wybierz kontakty klienta";

$lang["google_sheets_integration_can_manage_google_sheets"] = "Czy możesz zarządzać Arkuszami Google?";

return $lang;

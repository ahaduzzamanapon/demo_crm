<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["skype_integration"] = "Integracja Skype";
$lang["skype_integration_meetings"] = "Spotkania";
$lang["skype_integration_topic"] = "Temat";
$lang["skype_meetings"] = "Spotkania na Skypie";
$lang["skype_integration_join_meeting"] = "Dołącz do spotkania";
$lang["skype_integration_other_settings"] = "Inne ustawienia";
$lang["skype_integration_integrate_skype"] = "Zintegruj Skype";
$lang["skype_integration_who_can_manage_meetings"] = "Kto może zarządzać spotkaniami";
$lang["skype_integration_users_help_message"] = "Określ tylko członków zespołu niebędących administratorami. Administratorzy zawsze będą mieli dostęp.";
$lang["skype_integration_client_can_access_meetings"] = "Klient ma dostęp do spotkań?";
$lang["skype_integration_meeting_time"] = "Czas spotkania";
$lang["skype_integration_join_url"] = "Dołącz URL";
$lang["skype_integration_add_meeting"] = "Dodaj spotkanie";
$lang["skype_integration_edit_meeting"] = "Edytuj spotkanie";
$lang["skype_integration_delete_meeting"] = "Usuń spotkanie";
$lang["skype_integration_all_client_contacts"] = "Wszystkie kontakty klientów";
$lang["skype_integration_choose_client_contacts"] = "Wybierz kontakty klienta";
$lang["skype_integration_upcoming"] = "Nadchodzące";
$lang["skype_integration_recent"] = "Najnowsze";
$lang["skype_integration_past"] = "Przeszłość";

return $lang;

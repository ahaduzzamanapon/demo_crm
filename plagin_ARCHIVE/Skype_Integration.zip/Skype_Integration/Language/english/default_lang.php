<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["skype_integration"] = "Skype Integration";
$lang["skype_integration_meetings"] = "Meetings";
$lang["skype_integration_topic"] = "Topic";
$lang["skype_meetings"] = "Skype meetings";
$lang["skype_integration_join_meeting"] = "Join meeting";
$lang["skype_integration_other_settings"] = "Other settings";
$lang["skype_integration_integrate_skype"] = "Integrate Skype";
$lang["skype_integration_who_can_manage_meetings"] = "Who can manage meetings";
$lang["skype_integration_users_help_message"] = "Specify non-admin team members only. Admins will always get access.";
$lang["skype_integration_client_can_access_meetings"] = "Client can access meetings?";
$lang["skype_integration_meeting_time"] = "Meeting time";
$lang["skype_integration_join_url"] = "Join URL";
$lang["skype_integration_add_meeting"] = "Add meeting";
$lang["skype_integration_edit_meeting"] = "Edit meeting";
$lang["skype_integration_delete_meeting"] = "Delete meeting";
$lang["skype_integration_all_client_contacts"] = "All client contacts";
$lang["skype_integration_choose_client_contacts"] = "Choose client contacts";
$lang["skype_integration_upcoming"] = "Upcoming";
$lang["skype_integration_recent"] = "Recent";
$lang["skype_integration_past"] = "Past";

return $lang;

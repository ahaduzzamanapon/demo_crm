<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["skype_integration"] = "Интеграция со Skype";
$lang["skype_integration_meetings"] = "Встречи";
$lang["skype_integration_topic"] = "Тема";
$lang["skype_meetings"] = "Встречи по Skype";
$lang["skype_integration_join_meeting"] = "Присоединиться к встрече";
$lang["skype_integration_other_settings"] = "Другие настройки";
$lang["skype_integration_integrate_skype"] = "Интегрировать Skype";
$lang["skype_integration_who_can_manage_meetings"] = "Кто может управлять собраниями";
$lang["skype_integration_users_help_message"] = "Укажите только членов команды, не являющихся администраторами. Администраторы всегда будут иметь доступ.";
$lang["skype_integration_client_can_access_meetings"] = "Клиент может получить доступ к собраниям?";
$lang["skype_integration_meeting_time"] = "Время встречи";
$lang["skype_integration_join_url"] = "URL-адрес присоединения";
$lang["skype_integration_add_meeting"] = "Добавить встречу";
$lang["skype_integration_edit_meeting"] = "Редактировать встречу";
$lang["skype_integration_delete_meeting"] = "Удалить встречу";
$lang["skype_integration_all_client_contacts"] = "Все контакты клиентов";
$lang["skype_integration_choose_client_contacts"] = "Выбрать контакты клиента";
$lang["skype_integration_upcoming"] = "Скоро";
$lang["skype_integration_recent"] = "Недавние";
$lang["skype_integration_past"] = "Прошлое";

return $lang;

<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["skype_integration"] = "Intégration Skype";
$lang["skype_integration_meetings"] = "Réunions";
$lang["skype_integration_topic"] = "Sujet";
$lang["skype_meetings"] = "Réunions Skype";
$lang["skype_integration_join_meeting"] = "Rejoindre la réunion";
$lang["skype_integration_other_settings"] = "Autres paramètres";
$lang["skype_integration_integrate_skype"] = "Intégrer Skype";
$lang["skype_integration_who_can_manage_meetings"] = "Qui peut gérer les réunions";
$lang["skype_integration_users_help_message"] = "Spécifiez uniquement les membres de l'équipe non-administrateurs. Les administrateurs auront toujours accès.";
$lang["skype_integration_client_can_access_meetings"] = "Le client peut accéder aux réunions ?";
$lang["skype_integration_meeting_time"] = "Heure de la réunion";
$lang["skype_integration_join_url"] = "Rejoindre l'URL";
$lang["skype_integration_add_meeting"] = "Ajouter une réunion";
$lang["skype_integration_edit_meeting"] = "Modifier la réunion";
$lang["skype_integration_delete_meeting"] = "Supprimer la réunion";
$lang["skype_integration_all_client_contacts"] = "Tous les contacts clients";
$lang["skype_integration_choose_client_contacts"] = "Choisir les contacts clients";
$lang["skype_integration_upcoming"] = "À venir";
$lang["skype_integration_recent"] = "Récent";
$lang["skype_integration_past"] = "Passé";

return $lang;

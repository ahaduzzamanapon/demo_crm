<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["skype_integration"] = "Integrazione Skype";
$lang["skype_integration_meetings"] = "Riunioni";
$lang["skype_integration_topic"] = "Argomento";
$lang["skype_meetings"] = "Riunioni Skype";
$lang["skype_integration_join_meeting"] = "Partecipa alla riunione";
$lang["skype_integration_other_settings"] = "Altre impostazioni";
$lang["skype_integration_integrate_skype"] = "Integra Skype";
$lang["skype_integration_who_can_manage_meetings"] = "Chi può gestire i meeting";
$lang["skype_integration_users_help_message"] = "Specifica solo i membri del team non amministratori. Gli amministratori avranno sempre accesso.";
$lang["skype_integration_client_can_access_meetings"] = "Il cliente può accedere alle riunioni?";
$lang["skype_integration_meeting_time"] = "Ora della riunione";
$lang["skype_integration_join_url"] = "URL di partecipazione";
$lang["skype_integration_add_meeting"] = "Aggiungi riunione";
$lang["skype_integration_edit_meeting"] = "Modifica riunione";
$lang["skype_integration_delete_meeting"] = "Elimina riunione";
$lang["skype_integration_all_client_contacts"] = "Tutti i contatti del cliente";
$lang["skype_integration_choose_client_contacts"] = "Scegli i contatti del cliente";
$lang["skype_integration_upcoming"] = "Prossimo";
$lang["skype_integration_recent"] = "Recente";
$lang["skype_integration_past"] = "Passato";

return $lang;

<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["skype_integration"] = "Integración de Skype";
$lang["skype_integration_meetings"] = "Reuniones";
$lang["skype_integration_topic"] = "Tema";
$lang["skype_meetings"] = "Reuniones de Skype";
$lang["skype_integration_join_meeting"] = "Unirse a la reunión";
$lang["skype_integration_other_settings"] = "Otras configuraciones";
$lang["skype_integration_integrate_skype"] = "Integrar Skype";
$lang["skype_integration_who_can_manage_meetings"] = "Quién puede gestionar reuniones";
$lang["skype_integration_users_help_message"] = "Especifique solo los miembros del equipo que no sean administradores. Los administradores siempre tendrán acceso.";
$lang["skype_integration_client_can_access_meetings"] = "¿El cliente puede acceder a las reuniones?";
$lang["skype_integration_meeting_time"] = "Hora de la reunión";
$lang["skype_integration_join_url"] = "URL de ingreso";
$lang["skype_integration_add_meeting"] = "Agregar reunión";
$lang["skype_integration_edit_meeting"] = "Editar reunión";
$lang["skype_integration_delete_meeting"] = "Eliminar reunión";
$lang["skype_integration_all_client_contacts"] = "Todos los contactos del cliente";
$lang["skype_integration_choose_client_contacts"] = "Elija los contactos del cliente";
$lang["skype_integration_upcoming"] = "Próximo";
$lang["skype_integration_recent"] = "Reciente";
$lang["skype_integration_past"] = "Pasado";

return $lang;

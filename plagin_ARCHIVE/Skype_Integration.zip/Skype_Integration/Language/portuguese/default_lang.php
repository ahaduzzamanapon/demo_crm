<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["skype_integration"] = "Integração com Skype";
$lang["skype_integration_meetings"] = "Reuniões";
$lang["skype_integration_topic"] = "Tópico";
$lang["skype_meetings"] = "reuniões do Skype";
$lang["skype_integration_join_meeting"] = "Participar da reunião";
$lang["skype_integration_other_settings"] = "Outras configurações";
$lang["skype_integration_integrate_skype"] = "Integrar Skype";
$lang["skype_integration_who_can_manage_meetings"] = "Quem pode gerenciar reuniões";
$lang["skype_integration_users_help_message"] = "Especifique apenas membros não-administradores da equipe. Os administradores sempre terão acesso.";
$lang["skype_integration_client_can_access_meetings"] = "O cliente pode acessar as reuniões?";
$lang["skype_integration_meeting_time"] = "Hora da reunião";
$lang["skype_integration_join_url"] = "URL de inscrição";
$lang["skype_integration_add_meeting"] = "Adicionar reunião";
$lang["skype_integration_edit_meeting"] = "Editar reunião";
$lang["skype_integration_delete_meeting"] = "Excluir reunião";
$lang["skype_integration_all_client_contacts"] = "Todos os contatos do cliente";
$lang["skype_integration_choose_client_contacts"] = "Escolha os contatos do cliente";
$lang["skype_integration_upcoming"] = "Próximos";
$lang["skype_integration_recent"] = "Recentes";
$lang["skype_integration_past"] = "Passado";

return $lang;

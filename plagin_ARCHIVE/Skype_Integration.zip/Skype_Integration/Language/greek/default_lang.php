<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["skype_integration"] = "Ενσωμάτωση Skype";
$lang["skype_integration_meetings"] = "Συναντήσεις";
$lang["skype_integration_topic"] = "Θέμα";
$lang["skype_meetings"] = "Συναντήσεις Skype";
$lang["skype_integration_join_meeting"] = "Συμμετοχή στη συνάντηση";
$lang["skype_integration_other_settings"] = "Άλλες ρυθμίσεις";
$lang["skype_integration_integrate_skype"] = "Ενσωμάτωση Skype";
$lang["skype_integration_who_can_manage_meetings"] = "Ποιος μπορεί να διαχειριστεί συσκέψεις";
$lang["skype_integration_users_help_message"] = "Καθορίστε μόνο μέλη της ομάδας που δεν είναι διαχειριστές. Οι διαχειριστές θα έχουν πάντα πρόσβαση.";
$lang["skype_integration_client_can_access_meetings"] = "Ο πελάτης μπορεί να έχει πρόσβαση σε συσκέψεις;";
$lang["skype_integration_meeting_time"] = "Ώρα συνάντησης";
$lang["skype_integration_join_url"] = "Διεύθυνση URL συμμετοχής";
$lang["skype_integration_add_meeting"] = "Προσθήκη συνάντησης";
$lang["skype_integration_edit_meeting"] = "Επεξεργασία συνάντησης";
$lang["skype_integration_delete_meeting"] = "Διαγραφή συνάντησης";
$lang["skype_integration_all_client_contacts"] = "Όλες οι επαφές πελατών";
$lang["skype_integration_choose_client_contacts"] = "Επιλογή επαφών πελάτη";
$lang["skype_integration_upcoming"] = "Προσεχόμενα";
$lang["skype_integration_recent"] = "Πρόσφατα";
$lang["skype_integration_past"] = "Παρελθόν";

return $lang;

<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["skype_integration"] = "Integrace Skype";
$lang["skype_integration_meetings"] = "Schůzky";
$lang["skype_integration_topic"] = "Téma";
$lang["skype_meetings"] = "Schůzky přes Skype";
$lang["skype_integration_join_meeting"] = "Připojit se ke schůzce";
$lang["skype_integration_other_settings"] = "Další nastavení";
$lang["skype_integration_integrate_skype"] = "Integrovat Skype";
$lang["skype_integration_who_can_manage_meetings"] = "Kdo může řídit schůzky";
$lang["skype_integration_users_help_message"] = "Uveďte pouze členy týmu, kteří nejsou administrátory. Správci budou mít přístup vždy.";
$lang["skype_integration_client_can_access_meetings"] = "Klient má přístup ke schůzkám?";
$lang["skype_integration_meeting_time"] = "Čas schůzky";
$lang["skype_integration_join_url"] = "Připojit URL";
$lang["skype_integration_add_meeting"] = "Přidat schůzku";
$lang["skype_integration_edit_meeting"] = "Upravit schůzku";
$lang["skype_integration_delete_meeting"] = "Smazat schůzku";
$lang["skype_integration_all_client_contacts"] = "Všechny klientské kontakty";
$lang["skype_integration_choose_client_contacts"] = "Vyberte kontakty klienta";
$lang["skype_integration_upcoming"] = "Připravované";
$lang["skype_integration_recent"] = "Nedávné";
$lang["skype_integration_past"] = "Minulost";

return $lang;

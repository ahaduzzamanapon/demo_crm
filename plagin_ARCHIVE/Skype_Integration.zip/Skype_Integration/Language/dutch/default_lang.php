<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["skype_integration"] = "Skype-integratie";
$lang["skype_integration_meetings"] = "Vergaderingen";
$lang["skype_integration_topic"] = "Onderwerp";
$lang["skype_meetings"] = "Skype-vergaderingen";
$lang["skype_integration_join_meeting"] = "Deelnemen aan vergadering";
$lang["skype_integration_other_settings"] = "Andere instellingen";
$lang["skype_integration_integrate_skype"] = "Skype integreren";
$lang["skype_integration_who_can_manage_meetings"] = "Wie kan vergaderingen beheren";
$lang["skype_integration_users_help_message"] = "Specificeer alleen niet-beheerdersteamleden. Beheerders krijgen altijd toegang.";
$lang["skype_integration_client_can_access_meetings"] = "Klant heeft toegang tot vergaderingen?";
$lang["skype_integration_meeting_time"] = "Vergadertijd";
$lang["skype_integration_join_url"] = "Deelnemen aan URL";
$lang["skype_integration_add_meeting"] = "Vergadering toevoegen";
$lang["skype_integration_edit_meeting"] = "Vergadering bewerken";
$lang["skype_integration_delete_meeting"] = "Verwijder vergadering";
$lang["skype_integration_all_client_contacts"] = "Alle klantcontacten";
$lang["skype_integration_choose_client_contacts"] = "Kies klantcontacten";
$lang["skype_integration_upcoming"] = "Aankomend";
$lang["skype_integration_recent"] = "Recent";
$lang["skype_integration_past"] = "Verleden";

return $lang;

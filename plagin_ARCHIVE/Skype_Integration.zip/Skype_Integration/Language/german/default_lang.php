<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["skype_integration"] = "Skype-Integration";
$lang["skype_integration_meetings"] = "Besprechungen";
$lang["skype_integration_topic"] = "Thema";
$lang["skype_meetings"] = "Skype-Meetings";
$lang["skype_integration_join_meeting"] = "Meeting beitreten";
$lang["skype_integration_other_settings"] = "Andere Einstellungen";
$lang["skype_integration_integrate_skype"] = "Skype integrieren";
$lang["skype_integration_who_can_manage_meetings"] = "Wer kann Meetings verwalten";
$lang["skype_integration_users_help_message"] = "Geben Sie nur Nicht-Administrator-Teammitglieder an. Administratoren erhalten immer Zugriff.";
$lang["skype_integration_client_can_access_meetings"] = "Kunde kann auf Meetings zugreifen?";
$lang["skype_integration_meeting_time"] = "Besprechungszeit";
$lang["skype_integration_join_url"] = "Beitritts-URL";
$lang["skype_integration_add_meeting"] = "Meeting hinzufügen";
$lang["skype_integration_edit_meeting"] = "Meeting bearbeiten";
$lang["skype_integration_delete_meeting"] = "Meeting löschen";
$lang["skype_integration_all_client_contacts"] = "Alle Kundenkontakte";
$lang["skype_integration_choose_client_contacts"] = "Kundenkontakte auswählen";
$lang["skype_integration_upcoming"] = "Bevorstehend";
$lang["skype_integration_recent"] = "Zuletzt";
$lang["skype_integration_past"] = "Vergangenheit";

return $lang;

<?php

namespace Flexiblebackup\Config;

use CodeIgniter\Config\BaseConfig;

class Flexiblebackup extends BaseConfig
{
    public function __construct()
    {
    }
}

<?php

$lang['flexiblebackup_example'] = 'Example';

return $lang;

<?php
if(!defined('CTL_REG_PROD_POINT'))
    define('CTL_REG_PROD_POINT', 'https://api.corbitaltechnologies.com/api/register');
if(!defined('CTL_VAL_PROD_POINT'))
    define('CTL_VAL_PROD_POINT', 'https://api.corbitaltechnologies.com/api/validate');
if(!defined('CTL_GIVE_ME_CODE'))
    define('CTL_GIVE_ME_CODE', 'https://api.corbitaltechnologies.com/api/givemecode');
?>
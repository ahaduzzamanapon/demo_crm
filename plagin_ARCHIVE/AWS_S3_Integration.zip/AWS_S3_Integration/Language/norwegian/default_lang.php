<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["aws_s3_integration_integrate"] = "Integrer";
$lang["aws_s3_integration_access_key_id"] = "Tilgangsnøkkel-ID";
$lang["aws_s3_integration_secret_access_key"] = "Hemmelig tilgangsnøkkel";
$lang["aws_s3_integration_bucket_name"] = "Bøttenavn";
$lang["aws_s3_integration_bucket_naming_help_message"] = "Bøttenavn må være unikt og må ikke inneholde mellomrom eller store bokstaver.";
$lang["aws_s3_integration_see_rules_for_bucket_naming"] = "Se regler for navn på bøtte";
$lang["aws_s3_integration_get_your_access_keys_from_here"] = "Få tilgangsnøklene dine herfra";
$lang["aws_s3_integration_region"] = "Region";

return $lang;

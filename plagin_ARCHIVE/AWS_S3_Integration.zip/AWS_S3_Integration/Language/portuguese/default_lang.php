<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["aws_s3_integration_integrate"] = "Integrar";
$lang["aws_s3_integration_access_key_id"] = "ID da chave de acesso";
$lang["aws_s3_integration_secret_access_key"] = "Chave de acesso secreta";
$lang["aws_s3_integration_bucket_name"] = "Nome do bucket";
$lang["aws_s3_integration_bucket_naming_help_message"] = "O nome do bucket deve ser exclusivo e não deve conter espaços ou letras maiúsculas.";
$lang["aws_s3_integration_see_rules_for_bucket_naming"] = "Ver regras para nomenclatura de bucket";
$lang["aws_s3_integration_get_your_access_keys_from_here"] = "Obtenha suas chaves de acesso daqui";
$lang["aws_s3_integration_region"] = "Região";

return $lang;

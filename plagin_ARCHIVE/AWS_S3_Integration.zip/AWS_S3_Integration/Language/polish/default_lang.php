<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["aws_s3_integration_integrate"] = "Integruj";
$lang["aws_s3_integration_access_key_id"] = "Identyfikator klucza dostępu";
$lang["aws_s3_integration_secret_access_key"] = "Tajny klucz dostępu";
$lang["aws_s3_integration_bucket_name"] = "Nazwa zasobnika";
$lang["aws_s3_integration_bucket_naming_help_message"] = "Nazwa zasobnika musi być unikalna i nie może zawierać spacji ani wielkich liter.";
$lang["aws_s3_integration_see_rules_for_bucket_naming"] = "Zobacz reguły nazewnictwa zasobników";
$lang["aws_s3_integration_get_your_access_keys_from_here"] = "Pobierz swoje klucze dostępu stąd";
$lang["aws_s3_integration_region"] = "Region";

return $lang;

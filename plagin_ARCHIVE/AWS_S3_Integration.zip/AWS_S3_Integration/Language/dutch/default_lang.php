<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["aws_s3_integration_integrate"] = "Integreren";
$lang["aws_s3_integration_access_key_id"] = "Toegangssleutel ID";
$lang["aws_s3_integration_secret_access_key"] = "Geheime toegangssleutel";
$lang["aws_s3_integration_bucket_name"] = "Bucketnaam";
$lang["aws_s3_integration_bucket_naming_help_message"] = "Bucketnaam moet uniek zijn en mag geen spaties of hoofdletters bevatten.";
$lang["aws_s3_integration_see_rules_for_bucket_naming"] = "Bekijk regels voor het benoemen van buckets";
$lang["aws_s3_integration_get_your_access_keys_from_here"] = "Verkrijg hier uw toegangssleutels";
$lang["aws_s3_integration_region"] = "Regio";

return $lang;

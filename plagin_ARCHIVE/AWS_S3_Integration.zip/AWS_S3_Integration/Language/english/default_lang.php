<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["aws_s3_integration_integrate"] = "Integrate";
$lang["aws_s3_integration_access_key_id"] = "Access key ID";
$lang["aws_s3_integration_secret_access_key"] = "Secret access key";
$lang["aws_s3_integration_bucket_name"] = "Bucket name";
$lang["aws_s3_integration_bucket_naming_help_message"] = "Bucket name must be unique and must not contain spaces or uppercase letters.";
$lang["aws_s3_integration_see_rules_for_bucket_naming"] = "See rules for bucket naming";
$lang["aws_s3_integration_get_your_access_keys_from_here"] = "Get your access keys from here";
$lang["aws_s3_integration_region"] = "Region";

return $lang;

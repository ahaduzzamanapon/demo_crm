<?php

/* Don't change or add any new config in this file */

namespace Polls\Config;

use CodeIgniter\Config\BaseConfig;

class Polls extends BaseConfig {

    public $Polls_settings_array = array();

}

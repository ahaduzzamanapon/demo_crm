<?php //copy from default_lang.php file and update

$lang["polls_example"] = "Example";

return $lang;
<?php //copy from default_lang.php file and update

$lang["warehouse_example"] = "Example";

return $lang;
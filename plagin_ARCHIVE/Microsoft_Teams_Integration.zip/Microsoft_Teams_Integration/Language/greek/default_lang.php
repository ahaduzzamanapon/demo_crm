<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["microsoft_teams_integration"] = "Ενσωμάτωση Microsoft Teams";
$lang["microsoft_teams_integration_meetings"] = "Συναντήσεις";
$lang["microsoft_teams_integration_topic"] = "Θέμα";
$lang["microsoft_team_meetings"] = "Συναντήσεις Teams";
$lang["microsoft_teams_integration_join_meeting"] = "Συμμετοχή στη συνάντηση";
$lang["microsoft_teams_integration_other_settings"] = "Άλλες ρυθμίσεις";
$lang["microsoft_teams_integration_integrate_microsoft_teams"] = "Ενσωμάτωση Microsoft Teams";
$lang["microsoft_teams_integration_who_can_manage_meetings"] = "Ποιος μπορεί να διαχειριστεί συσκέψεις";
$lang["microsoft_teams_integration_users_help_message"] = "Καθορίστε μόνο μέλη της ομάδας που δεν είναι διαχειριστές. Οι διαχειριστές θα έχουν πάντα πρόσβαση.";
$lang["microsoft_teams_integration_client_can_access_meetings"] = "Ο πελάτης μπορεί να έχει πρόσβαση σε συσκέψεις;";
$lang["microsoft_teams_integration_meeting_time"] = "Ώρα συνάντησης";
$lang["microsoft_teams_integration_join_url"] = "Διεύθυνση URL συμμετοχής";
$lang["microsoft_teams_integration_add_meeting"] = "Προσθήκη συνάντησης";
$lang["microsoft_teams_integration_edit_meeting"] = "Επεξεργασία συνάντησης";
$lang["microsoft_teams_integration_delete_meeting"] = "Διαγραφή συνάντησης";
$lang["microsoft_teams_integration_all_client_contacts"] = "Όλες οι επαφές πελατών";
$lang["microsoft_teams_integration_choose_client_contacts"] = "Επιλογή επαφών πελάτη";
$lang["microsoft_teams_integration_upcoming"] = "Προσεχόμενα";
$lang["microsoft_teams_integration_recent"] = "Πρόσφατα";
$lang["microsoft_teams_integration_past"] = "Παρελθόν";

return $lang;

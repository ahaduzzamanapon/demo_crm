<?php //copy from default_lang.php file and update

$lang["microsoft_teams_integration_example"] = "Example";

return $lang;
<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["microsoft_teams_integration"] = "Microsoft Teams Integration";
$lang["microsoft_teams_integration_meetings"] = "Meetings";
$lang["microsoft_teams_integration_topic"] = "Topic";
$lang["microsoft_team_meetings"] = "Team meetings";
$lang["microsoft_teams_integration_join_meeting"] = "Join meeting";
$lang["microsoft_teams_integration_other_settings"] = "Other settings";
$lang["microsoft_teams_integration_integrate_microsoft_teams"] = "Integrate Microsoft Teams";
$lang["microsoft_teams_integration_who_can_manage_meetings"] = "Who can manage meetings";
$lang["microsoft_teams_integration_users_help_message"] = "Specify non-admin team members only. Admins will always get access.";
$lang["microsoft_teams_integration_client_can_access_meetings"] = "Client can access meetings?";
$lang["microsoft_teams_integration_meeting_time"] = "Meeting time";
$lang["microsoft_teams_integration_join_url"] = "Join URL";
$lang["microsoft_teams_integration_add_meeting"] = "Add meeting";
$lang["microsoft_teams_integration_edit_meeting"] = "Edit meeting";
$lang["microsoft_teams_integration_delete_meeting"] = "Delete meeting";
$lang["microsoft_teams_integration_all_client_contacts"] = "All client contacts";
$lang["microsoft_teams_integration_choose_client_contacts"] = "Choose client contacts";
$lang["microsoft_teams_integration_upcoming"] = "Upcoming";
$lang["microsoft_teams_integration_recent"] = "Recent";
$lang["microsoft_teams_integration_past"] = "Past";

return $lang;

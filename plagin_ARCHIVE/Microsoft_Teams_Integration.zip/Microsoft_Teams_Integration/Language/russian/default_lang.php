<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["microsoft_teams_integration"] = "Интеграция со Microsoft Teams";
$lang["microsoft_teams_integration_meetings"] = "Встречи";
$lang["microsoft_teams_integration_topic"] = "Тема";
$lang["microsoft_team_meetings"] = "Встречи по Teams";
$lang["microsoft_teams_integration_join_meeting"] = "Присоединиться к встрече";
$lang["microsoft_teams_integration_other_settings"] = "Другие настройки";
$lang["microsoft_teams_integration_integrate_microsoft_teams"] = "Интегрировать Microsoft Teams";
$lang["microsoft_teams_integration_who_can_manage_meetings"] = "Кто может управлять собраниями";
$lang["microsoft_teams_integration_users_help_message"] = "Укажите только членов команды, не являющихся администраторами. Администраторы всегда будут иметь доступ.";
$lang["microsoft_teams_integration_client_can_access_meetings"] = "Клиент может получить доступ к собраниям?";
$lang["microsoft_teams_integration_meeting_time"] = "Время встречи";
$lang["microsoft_teams_integration_join_url"] = "URL-адрес присоединения";
$lang["microsoft_teams_integration_add_meeting"] = "Добавить встречу";
$lang["microsoft_teams_integration_edit_meeting"] = "Редактировать встречу";
$lang["microsoft_teams_integration_delete_meeting"] = "Удалить встречу";
$lang["microsoft_teams_integration_all_client_contacts"] = "Все контакты клиентов";
$lang["microsoft_teams_integration_choose_client_contacts"] = "Выбрать контакты клиента";
$lang["microsoft_teams_integration_upcoming"] = "Скоро";
$lang["microsoft_teams_integration_recent"] = "Недавние";
$lang["microsoft_teams_integration_past"] = "Прошлое";

return $lang;

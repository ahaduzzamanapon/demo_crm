<?php //copy from default_lang.php file and update

$lang["password_manager_example"] = "Example";

return $lang;
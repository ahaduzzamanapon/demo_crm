<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["timecamp_integration"] = "Timecamp Integration";
$lang["enable_timecamp"] = "Enable Timecamp";
$lang["timecamp_help_note"] = "It'll be one way (RISE to Timecamp) integration.";
$lang["timecamp_specific_projects"] = "Specific projects";
$lang["timecamp_sync"] = "Sync";
$lang["timecamp_sync_status"] = "Sync status";
$lang["timecamp_synced"] = "Synced";
$lang["timecamp_partially"] = "Partially";
$lang["timecamp_fully"] = "Fully";
$lang["timecamp_api_token"] = "API token";
$lang["timecamp_get_your_api_token_from_here"] = "Get your API token from here:";

return $lang;

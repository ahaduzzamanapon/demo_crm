<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["google_meet_integration"] = "Google Meet-Integration";
$lang["google_meet_integration_meetings"] = "Besprechungen";
$lang["google_meet_integration_topic"] = "Thema";
$lang["google_meet_meetings"] = "Google Meet-Meetings";
$lang["google_meet"] = "Google Meet";
$lang["google_meet_integration_join_meeting"] = "Meeting beitreten";
$lang["google_meet_integration_other_settings"] = "Andere Einstellungen";
$lang["google_meet_integration_integrate_google_meet"] = "Google Meet integrieren";
$lang["google_meet_integration_who_can_manage_meetings"] = "Wer kann Meetings verwalten";
$lang["google_meet_integration_users_help_message"] = "Geben Sie nur Nicht-Administrator-Teammitglieder an. Administratoren erhalten immer Zugriff.";
$lang["google_meet_integration_client_can_access_meetings"] = "Kunde kann auf Meetings zugreifen?";
$lang["google_meet_integration_meeting_time"] = "Besprechungszeit";
$lang["google_meet_integration_join_url"] = "Beitritts-URL";
$lang["google_meet_integration_add_meeting"] = "Meeting hinzufügen";
$lang["google_meet_integration_edit_meeting"] = "Meeting bearbeiten";
$lang["google_meet_integration_delete_meeting"] = "Meeting löschen";
$lang["google_meet_integration_all_client_contacts"] = "Alle Kundenkontakte";
$lang["google_meet_integration_choose_client_contacts"] = "Kundenkontakte auswählen";
$lang["google_meet_integration_upcoming"] = "Bevorstehend";
$lang["google_meet_integration_recent"] = "Zuletzt";
$lang["google_meet_integration_past"] = "Vergangenheit";

return $lang;

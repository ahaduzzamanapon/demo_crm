<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["google_meet_integration"] = "Integración de Google Meet";
$lang["google_meet_integration_meetings"] = "Reuniones";
$lang["google_meet_integration_topic"] = "Tema";
$lang["google_meet_meetings"] = "Reuniones de Google Meet";
$lang["google_meet"] = "Reunión de Google";
$lang["google_meet_integration_join_meeting"] = "Unirse a la reunión";
$lang["google_meet_integration_other_settings"] = "Otras configuraciones";
$lang["google_meet_integration_integrate_google_meet"] = "Integrar Google Meet";
$lang["google_meet_integration_who_can_manage_meetings"] = "Quién puede gestionar reuniones";
$lang["google_meet_integration_users_help_message"] = "Especifique solo los miembros del equipo que no sean administradores. Los administradores siempre tendrán acceso.";
$lang["google_meet_integration_client_can_access_meetings"] = "¿El cliente puede acceder a las reuniones?";
$lang["google_meet_integration_meeting_time"] = "Hora de la reunión";
$lang["google_meet_integration_join_url"] = "URL de ingreso";
$lang["google_meet_integration_add_meeting"] = "Agregar reunión";
$lang["google_meet_integration_edit_meeting"] = "Editar reunión";
$lang["google_meet_integration_delete_meeting"] = "Eliminar reunión";
$lang["google_meet_integration_all_client_contacts"] = "Todos los contactos del cliente";
$lang["google_meet_integration_choose_client_contacts"] = "Elija los contactos del cliente";
$lang["google_meet_integration_upcoming"] = "Próximo";
$lang["google_meet_integration_recent"] = "Reciente";
$lang["google_meet_integration_past"] = "Pasado";

return $lang;

<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["whiteboards"] = "Whiteboards";
$lang["whiteboards_client_can_access_whiteboards"] = "Klienten har tilgang til tavler?";
$lang["whiteboards_add_whiteboard"] = "Legg til tavle";
$lang["whiteboards_edit_whiteboard"] = "Rediger tavle";
$lang["whiteboards_delete_whiteboard"] = "Slett tavle";
$lang["whiteboards_all_client_contacts"] = "Alle klientkontakter";
$lang["whiteboards_choose_client_contacts"] = "Velg klientkontakter";
$lang["whiteboards_can_manage_whiteboards"] = "Kan administrere tavler?";
$lang["whiteboard_permission"] = "Tillatelse";
$lang["whiteboard_viewer"] = "Seer";
$lang["whiteboard_editor"] = "Redaktør";

return $lang;

<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["whiteboards"] = "Whiteboards";
$lang["whiteboards_client_can_access_whiteboards"] = "Klant heeft toegang tot whiteboards?";
$lang["whiteboards_add_whiteboard"] = "Whiteboard toevoegen";
$lang["whiteboards_edit_whiteboard"] = "Whiteboard bewerken";
$lang["whiteboards_delete_whiteboard"] = "Witbord verwijderen";
$lang["whiteboards_all_client_contacts"] = "Alle klantcontacten";
$lang["whiteboards_choose_client_contacts"] = "Kies klantcontacten";
$lang["whiteboards_can_manage_whiteboards"] = "Kan whiteboards beheren?";
$lang["whiteboard_permission"] = "Toestemming";
$lang["whiteboard_viewer"] = "Bekijker";
$lang["whiteboard_editor"] = "Bewerker";

return $lang;

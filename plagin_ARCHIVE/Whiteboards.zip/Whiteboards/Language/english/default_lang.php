<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["whiteboards"] = "Whiteboards";
$lang["whiteboards_client_can_access_whiteboards"] = "Client can access Whiteboards?";
$lang["whiteboards_add_whiteboard"] = "Add whiteboard";
$lang["whiteboards_edit_whiteboard"] = "Edit whiteboard";
$lang["whiteboards_delete_whiteboard"] = "Delete whiteboard";
$lang["whiteboards_all_client_contacts"] = "All client contacts";
$lang["whiteboards_choose_client_contacts"] = "Choose client contacts";
$lang["whiteboards_can_manage_whiteboards"] = "Can manage Whiteboards?";
$lang["whiteboard_permission"] = "Permission";
$lang["whiteboard_viewer"] = "Viewer";
$lang["whiteboard_editor"] = "Editor";

return $lang;

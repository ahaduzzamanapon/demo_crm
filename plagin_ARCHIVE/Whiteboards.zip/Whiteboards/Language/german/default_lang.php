<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["whiteboards"] = "Whiteboards";
$lang["whiteboards_client_can_access_whiteboards"] = "Client kann auf Whiteboards zugreifen?";
$lang["whiteboards_add_whiteboard"] = "Whiteboard hinzufügen";
$lang["whiteboards_edit_whiteboard"] = "Whiteboard bearbeiten";
$lang["whiteboards_delete_whiteboard"] = "Whiteboard löschen";
$lang["whiteboards_all_client_contacts"] = "Alle Kundenkontakte";
$lang["whiteboards_choose_client_contacts"] = "Kundenkontakte auswählen";
$lang["whiteboards_can_manage_whiteboards"] = "Kann Whiteboards verwalten?";
$lang["whiteboard_permission"] = "Berechtigung";
$lang["whiteboard_viewer"] = "Viewer";
$lang["whiteboard_editor"] = "Editor";

return $lang;

<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["pizarras"] = "Pizarras";
$lang["whiteboards_client_can_access_whiteboards"] = "¿El cliente puede acceder a las pizarras?";
$lang["whiteboards_add_whiteboard"] = "Agregar pizarra";
$lang["whiteboards_edit_whiteboard"] = "Editar pizarra";
$lang["whiteboards_delete_whiteboard"] = "Eliminar pizarra";
$lang["whiteboards_all_client_contacts"] = "Todos los contactos del cliente";
$lang["whiteboards_choose_client_contacts"] = "Elegir contactos del cliente";
$lang["whiteboards_can_manage_whiteboards"] = "¿Puedes administrar pizarras blancas?";
$lang["whiteboard_permission"] = "Permiso";
$lang["whiteboard_viewer"] = "Visor";
$lang["whiteboard_editor"] = "Editor";

return $lang;

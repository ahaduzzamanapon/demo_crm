<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["tablice"] = "Tablice";
$lang["whiteboards_client_can_access_whiteboards"] = "Klient może uzyskać dostęp do tablic?";
$lang["whiteboards_add_whiteboard"] = "Dodaj tablicę";
$lang["whiteboards_edit_whiteboard"] = "Edytuj tablicę";
$lang["whiteboards_delete_whiteboard"] = "Usuń tablicę";
$lang["whiteboards_all_client_contacts"] = "Wszystkie kontakty klienta";
$lang["whiteboards_choose_client_contacts"] = "Wybierz kontakty klienta";
$lang["whiteboards_can_manage_whiteboards"] = "Czy można zarządzać tablicami?";
$lang["whiteboard_permission"] = "Pozwolenie";
$lang["whiteboard_viewer"] = "Przeglądarka";
$lang["whiteboard_editor"] = "Edytor";

return $lang;

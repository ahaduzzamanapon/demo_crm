<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["whiteboards"] = "Lavagne";
$lang["whiteboards_client_can_access_whiteboards"] = "Il cliente può accedere alle lavagne?";
$lang["whiteboards_add_whiteboard"] = "Aggiungi lavagna";
$lang["whiteboards_edit_whiteboard"] = "Modifica lavagna";
$lang["whiteboards_delete_whiteboard"] = "Elimina lavagna";
$lang["whiteboards_all_client_contacts"] = "Tutti i contatti del cliente";
$lang["whiteboards_choose_client_contacts"] = "Scegli i contatti del cliente";
$lang["whiteboards_can_manage_whiteboards"] = "Può gestire le lavagne?";
$lang["whiteboard_permission"] = "Autorizzazione";
$lang["whiteboard_viewer"] = "Visualizzatore";
$lang["whiteboard_editor"] = "Editor";

return $lang;

<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["whiteboards"] = "Bílé tabule";
$lang["whiteboards_client_can_access_whiteboards"] = "Klient má přístup k tabulím?";
$lang["whiteboards_add_whiteboard"] = "Přidat bílou tabuli";
$lang["whiteboards_edit_whiteboard"] = "Upravit bílou tabuli";
$lang["whiteboards_delete_whiteboard"] = "Smazat bílou tabuli";
$lang["whiteboards_all_client_contacts"] = "Všechny klientské kontakty";
$lang["whiteboards_choose_client_contacts"] = "Vyberte kontakty klienta";
$lang["whiteboards_can_manage_whiteboards"] = "Umíte spravovat tabule?";
$lang["whiteboard_permission"] = "Povolení";
$lang["whiteboard_viewer"] = "Prohlížeč";
$lang["whiteboard_editor"] = "Editor";

return $lang;

<?php //copy from default_lang.php file and update

$lang["whiteboards_example"] = "Example";

return $lang;
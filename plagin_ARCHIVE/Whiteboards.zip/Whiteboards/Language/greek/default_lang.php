<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["whiteboards"] = "Whiteboards";
$lang["whiteboards_client_can_access_whiteboards"] = "Ο πελάτης μπορεί να έχει πρόσβαση στους λευκούς πίνακες;";
$lang["whiteboards_add_whiteboard"] = "Προσθήκη πίνακα";
$lang["whiteboards_edit_whiteboard"] = "Επεξεργασία λευκού πίνακα";
$lang["whiteboards_delete_whiteboard"] = "Διαγραφή λευκού πίνακα";
$lang["whiteboards_all_client_contacts"] = "Όλες οι επαφές πελατών";
$lang["whiteboards_choose_client_contacts"] = "Επιλογή επαφών πελάτη";
$lang["whiteboards_can_manage_whiteboards"] = "Μπορείτε να διαχειριστείτε λευκούς πίνακες;";
$lang["whiteboard_permission"] = "Άδεια";
$lang["whiteboard_viewer"] = "Προβολή";
$lang["whiteboard_editor"] = "Επεξεργαστής";

return $lang;

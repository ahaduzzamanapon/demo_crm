<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["quadros brancos"] = "Quadros brancos";
$lang["whiteboards_client_can_access_whiteboards"] = "O cliente pode acessar os quadros brancos?";
$lang["whiteboards_add_whiteboard"] = "Adicionar quadro branco";
$lang["whiteboards_edit_whiteboard"] = "Editar quadro branco";
$lang["whiteboards_delete_whiteboard"] = "Excluir quadro branco";
$lang["whiteboards_all_client_contacts"] = "Todos os contatos do cliente";
$lang["whiteboards_choose_client_contacts"] = "Escolha os contatos do cliente";
$lang["whiteboards_can_manage_whiteboards"] = "É possível gerenciar quadros brancos?";
$lang["whiteboard_permission"] = "Permissão";
$lang["whiteboard_viewer"] = "Visualizador";
$lang["whiteboard_editor"] = "Editor";

return $lang;

<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang [ " telegram_notification " ] = " Ειδοποίηση Τηλεγραφήματος " ;
$lang["telegram_integration_settings"] = "Ρυθμίσεις ειδοποίησης τηλεγραφήματος";
$lang["enable_telegram"] = "Ενεργοποίηση Telegram";
$lang["telegram_bot_token"] = "Bot Token";
$lang["telegram_chat_id"] = "Αναγνωριστικό συνομιλίας";
$lang["notification_test_telegram_notification"] = "Αυτό είναι ένα μήνυμα επίδειξης.";
$lang["telegram_notification_error_message"] = "Σφάλμα! Δεν είναι δυνατή η σύνδεση με το Telegram χρησιμοποιώντας τα διαπιστευτήρια.";
$lang["telegram_notification_enable_telegram"] = "Ενεργοποίηση Telegram";
$lang["telegram_notification_edit_instruction"] = "Πρέπει να είναι ενεργοποιημένη η ειδοποίηση Ιστού στις ρυθμίσεις ειδοποιήσεων εφαρμογής για να λαμβάνετε ειδοποίηση στο Telegram.";

return $lang;

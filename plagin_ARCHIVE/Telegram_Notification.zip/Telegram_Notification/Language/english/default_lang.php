<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["telegram_notification"] = "Telegram Notification";
$lang["telegram_integration_settings"] = "Telegram notification settings";
$lang["enable_telegram"] = "Enable Telegram";
$lang["telegram_bot_token"] = "Bot Token";
$lang["telegram_chat_id"] = "Chat ID";
$lang["notification_test_telegram_notification"] = "This is a demo message.";
$lang["telegram_notification_error_message"] = "Error! Can't connect with the Telegram using the credentials.";
$lang["telegram_notification_enable_telegram"] = "Enable Telegram";
$lang["telegram_notification_edit_instruction"] = "There must be web notification enabled in app notification settings to get Telegram notification.";

return $lang;

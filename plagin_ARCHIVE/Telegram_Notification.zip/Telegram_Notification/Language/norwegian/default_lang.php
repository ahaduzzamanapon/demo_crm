<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["telegram_notification"] = "Telegramvarsling";
$lang["telegram_integration_settings"] = "Innstillinger for telegramvarsling";
$lang["enable_telegram"] = "Aktiver Telegram";
$lang["telegram_bot_token"] = "Bot-token";
$lang["telegram_chat_id"] = "Chat-ID";
$lang["notification_test_telegram_notification"] = "Dette er en demomelding.";
$lang["telegram_notification_error_message"] = "Feil! Kan ikke koble til Telegrammet ved å bruke legitimasjonen.";
$lang["telegram_notification_enable_telegram"] = "Aktiver Telegram";
$lang["telegram_notification_edit_instruction"] = "Det må være nettvarsling aktivert i appvarslingsinnstillingene for å få Telegram-varsling.";

return $lang;

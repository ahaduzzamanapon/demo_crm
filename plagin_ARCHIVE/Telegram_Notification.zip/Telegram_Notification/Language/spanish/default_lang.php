<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["telegram_notification"] = "Notificación de telegrama";
$lang["telegram_integration_settings"] = "Configuración de notificaciones de Telegram";
$lang["enable_telegram"] = "Habilitar Telegram";
$lang["telegram_bot_token"] = "Token de bot";
$lang["telegram_chat_id"] = "ID de chat";
$lang["notification_test_telegram_notification"] = "Este es un mensaje de demostración.";
$lang["telegram_notification_error_message"] = "¡Error! No puedo conectarme con Telegram usando las credenciales.";
$lang["telegram_notification_enable_telegram"] = "Habilitar Telegram";
$lang["telegram_notification_edit_instruction"] = "Debe haber notificaciones web habilitadas en la configuración de notificaciones de la aplicación para recibir notificaciones de Telegram.";

return $lang;

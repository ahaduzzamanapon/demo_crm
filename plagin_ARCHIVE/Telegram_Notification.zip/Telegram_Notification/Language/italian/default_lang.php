<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["telegram_notification"] = "Notifica telegramma";
$lang["telegram_integration_settings"] = "Impostazioni di notifica del telegramma";
$lang["enable_telegram"] = "Abilita telegramma";
$lang["telegram_bot_token"] = "Token bot";
$lang["telegram_chat_id"] = "ID chat";
$lang["notification_test_telegram_notification"] = "Questo è un messaggio dimostrativo.";
$lang["telegram_notification_error_message"] = "Errore! Impossibile connettersi al Telegram utilizzando le credenziali.";
$lang["telegram_notification_enable_telegram"] = "Abilita telegramma";
$lang["telegram_notification_edit_instruction"] = "Deve essere abilitata la notifica web nelle impostazioni di notifica dell'app per ricevere la notifica di Telegram.";

return $lang;

<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["telegram_notification"] = "Powiadomienie o telegramie";
$lang["telegram_integration_settings"] = "Ustawienia powiadomień o telegramie";
$lang["enable_telegram"] = "Włącz Telegram";
$lang["telegram_bot_token"] = "Token bota";
$lang["telegram_chat_id"] = "ID czatu";
$lang["notification_test_telegram_notification"] = "To jest wiadomość demo.";
$lang["telegram_notification_error_message"] = "Błąd! Nie można połączyć się z Telegramem przy użyciu danych uwierzytelniających.";
$lang["telegram_notification_enable_telegram"] = "Włącz Telegram";
$lang["telegram_notification_edit_instruction"] = "Musi być włączone powiadomienia sieciowe w ustawieniach powiadomień aplikacji, aby otrzymywać powiadomienia Telegrama.";

return $lang;

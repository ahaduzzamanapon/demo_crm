<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["login_as_client"] = "Log in als klant";
$lang["login_as_client_login"] = "Inloggen";
$lang["login_as_client_login_back_to_admin"] = "Log opnieuw in bij Admin";

return $lang;

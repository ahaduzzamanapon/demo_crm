<?php //copy from default_lang.php file and update

$lang["login_as_client_example"] = "Example";

return $lang;
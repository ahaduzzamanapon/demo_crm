<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["login_as_client"] = "Iniciar sesión como cliente";
$lang["login_as_client_login"] = "Iniciar sesión";
$lang["login_as_client_login_back_to_admin"] = "Regresar a Admin";

return $lang;

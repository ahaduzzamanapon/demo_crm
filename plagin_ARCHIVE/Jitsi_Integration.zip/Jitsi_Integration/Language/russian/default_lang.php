<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["jitsi_integration"] = "Интеграция Jitsi";
$lang["jitsi_integration_meetings"] = "Встречи";
$lang["jitsi_integration_topic"] = "Тема";
$lang["jitsi_meetings"] = "Встречи джитси";
$lang["jitsi_integration_join_meeting"] = "Присоединиться к встрече";
$lang["jitsi_integration_enable_jitsi_meetings"] = "Включить встречи Jitsi";
$lang["jitsi_integration_who_can_manage_meetings"] = "Кто может управлять собраниями";
$lang["jitsi_integration_users_help_message"] = "Укажите только членов команды, не являющихся администраторами. Администраторы всегда будут получать доступ.";
$lang["jitsi_integration_client_can_access_meetings"] = "Клиент может получить доступ к собраниям?";
$lang["jitsi_integration_meeting_time"] = "Время встречи";
$lang["jitsi_integration_join_url"] = "URL-адрес присоединения";
$lang["jitsi_integration_add_meeting"] = "Добавить встречу";
$lang["jitsi_integration_edit_meeting"] = "Редактировать встречу";
$lang["jitsi_integration_delete_meeting"] = "Удалить встречу";
$lang["jitsi_integration_all_client_contacts"] = "Все контакты клиентов";
$lang["jitsi_integration_choose_client_contacts"] = "Выбрать контакты клиента";
$lang["jitsi_integration_upcoming"] = "Предстоящие";
$lang["jitsi_integration_recent"] = "Недавние";
$lang["jitsi_integration_past"] = "Прошлое";

return $lang;

<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["jitsi_integration"] = "Ένταξη Τζίτση";
$lang["jitsi_integration_meetings"] = "Συναντήσεις";
$lang["jitsi_integration_topic"] = "Θέμα";
$lang["jitsi_meetings"] = "Συναντήσεις Τζίτση";
$lang["jitsi_integration_join_meeting"] = "Συμμετοχή στη συνάντηση";
$lang["jitsi_integration_enable_jitsi_meetings"] = "Ενεργοποίηση συσκέψεων Jitsi";
$lang["jitsi_integration_who_can_manage_meetings"] = "Ποιος μπορεί να διαχειρίζεται συσκέψεις";
$lang["jitsi_integration_users_help_message"] = "Καθορίστε μόνο μέλη της ομάδας που δεν είναι διαχειριστές. Οι διαχειριστές θα έχουν πάντα πρόσβαση.";
$lang["jitsi_integration_client_can_access_meetings"] = "Ο πελάτης έχει πρόσβαση σε συσκέψεις;";
$lang["jitsi_integration_meeting_time"] = "Ώρα συνάντησης";
$lang["jitsi_integration_join_url"] = "Διεύθυνση URL συμμετοχής";
$lang["jitsi_integration_add_meeting"] = "Προσθήκη συνάντησης";
$lang["jitsi_integration_edit_meeting"] = "Επεξεργασία συνάντησης";
$lang["jitsi_integration_delete_meeting"] = "Διαγραφή συνάντησης";
$lang["jitsi_integration_all_client_contacts"] = "Όλες οι επαφές πελατών";
$lang["jitsi_integration_choose_client_contacts"] = "Επιλογή επαφών πελάτη";
$lang["jitsi_integration_upcoming"] = "Επερχόμενα";
$lang["jitsi_integration_recent"] = "Πρόσφατα";
$lang["jitsi_integration_past"] = "Παρελθόν";

return $lang;

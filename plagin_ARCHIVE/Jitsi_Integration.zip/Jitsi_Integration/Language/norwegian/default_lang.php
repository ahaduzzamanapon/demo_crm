<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["jitsi_integration"] = "Jitsi-integrasjon";
$lang["jitsi_integration_meetings"] = "Møter";
$lang["jitsi_integration_topic"] = "Emne";
$lang["jitsi_meetings"] = "Jitsi møter";
$lang["jitsi_integration_join_meeting"] = "Bli med i møte";
$lang["jitsi_integration_enable_jitsi_meetings"] = "Aktiver Jitsi-møter";
$lang["jitsi_integration_who_can_manage_meetings"] = "Hvem kan administrere møter";
$lang["jitsi_integration_users_help_message"] = "Spesifiser bare ikke-admin teammedlemmer. Administratorer vil alltid få tilgang.";
$lang["jitsi_integration_client_can_access_meetings"] = "Klient kan få tilgang til møter?";
$lang["jitsi_integration_meeting_time"] = "Møtetid";
$lang["jitsi_integration_join_url"] = "Bli med URL";
$lang["jitsi_integration_add_meeting"] = "Legg til møte";
$lang["jitsi_integration_edit_meeting"] = "Rediger møte";
$lang["jitsi_integration_delete_meeting"] = "Slett møte";
$lang["jitsi_integration_all_client_contacts"] = "Alle klientkontakter";
$lang["jitsi_integration_choose_client_contacts"] = "Velg klientkontakter";
$lang["jitsi_integration_upcoming"] = "Kommende";
$lang["jitsi_integration_recent"] = "Nylig";
$lang["jitsi_integration_past"] = "Fortid";

return $lang;

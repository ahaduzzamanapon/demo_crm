<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["jitsi_integration"] = "Integrace Jitsi";
$lang["jitsi_integration_meetings"] = "Schůzky";
$lang["jitsi_integration_topic"] = "Téma";
$lang["jitsi_meetings"] = "Jitsi setkání";
$lang["jitsi_integration_join_meeting"] = "Připojit se ke schůzce";
$lang["jitsi_integration_enable_jitsi_meetings"] = "Povolit schůzky Jitsi";
$lang["jitsi_integration_who_can_manage_meetings"] = "Kdo může řídit schůzky";
$lang["jitsi_integration_users_help_message"] = "Určete pouze členy týmu, kteří nejsou administrátory. Správci budou mít přístup vždy.";
$lang["jitsi_integration_client_can_access_meetings"] = "Klient má přístup ke schůzkám?";
$lang["jitsi_integration_meeting_time"] = "Čas schůzky";
$lang["jitsi_integration_join_url"] = "Připojit URL";
$lang["jitsi_integration_add_meeting"] = "Přidat schůzku";
$lang["jitsi_integration_edit_meeting"] = "Upravit schůzku";
$lang["jitsi_integration_delete_meeting"] = "Smazat schůzku";
$lang["jitsi_integration_all_client_contacts"] = "Všechny klientské kontakty";
$lang["jitsi_integration_choose_client_contacts"] = "Vyberte kontakty klienta";
$lang["jitsi_integration_upcoming"] = "Připravované";
$lang["jitsi_integration_recent"] = "Nedávné";
$lang["jitsi_integration_past"] = "Minulost";

return $lang;

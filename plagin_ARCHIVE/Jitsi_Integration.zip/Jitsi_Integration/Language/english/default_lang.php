<?php

/* NOTE: DO NOT CHANGE THIS FILE. IF YOU WANT TO UPDATE THE LANGUAGE THEN COPY THIS FILE TO custom_lang.php AND UPDATE THERE */

$lang["jitsi_integration"] = "Jitsi Integration";
$lang["jitsi_integration_meetings"] = "Meetings";
$lang["jitsi_integration_topic"] = "Topic";
$lang["jitsi_meetings"] = "Jitsi meetings";
$lang["jitsi_integration_join_meeting"] = "Join meeting";
$lang["jitsi_integration_enable_jitsi_meetings"] = "Enable Jitsi meetings";
$lang["jitsi_integration_who_can_manage_meetings"] = "Who can manage meetings";
$lang["jitsi_integration_users_help_message"] = "Specify non-admin team members only. Admins will always get access.";
$lang["jitsi_integration_client_can_access_meetings"] = "Client can access meetings?";
$lang["jitsi_integration_meeting_time"] = "Meeting time";
$lang["jitsi_integration_join_url"] = "Join URL";
$lang["jitsi_integration_add_meeting"] = "Add meeting";
$lang["jitsi_integration_edit_meeting"] = "Edit meeting";
$lang["jitsi_integration_delete_meeting"] = "Delete meeting";
$lang["jitsi_integration_all_client_contacts"] = "All client contacts";
$lang["jitsi_integration_choose_client_contacts"] = "Choose client contacts";
$lang["jitsi_integration_upcoming"] = "Upcoming";
$lang["jitsi_integration_recent"] = "Recent";
$lang["jitsi_integration_past"] = "Past";

return $lang;

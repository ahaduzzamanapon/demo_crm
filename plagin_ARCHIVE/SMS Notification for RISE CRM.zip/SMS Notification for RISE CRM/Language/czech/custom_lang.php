<?php //copy from default_lang.php file and update

$lang["sms_example"] = "Example";

return $lang;
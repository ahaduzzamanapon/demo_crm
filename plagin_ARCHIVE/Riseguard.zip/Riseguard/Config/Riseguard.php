<?php

namespace Riseguard\Config;

use CodeIgniter\Config\BaseConfig;

class Riseguard extends BaseConfig {

    public function __construct() {
       
    }

}

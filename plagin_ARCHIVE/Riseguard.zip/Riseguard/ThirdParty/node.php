<?php
if(!defined('REG_PROD_POINT'))
    define('REG_PROD_POINT', 'https://envato.toofasthost.com/api/register');
if(!defined('VAL_PROD_POINT'))
    define('VAL_PROD_POINT', 'https://envato.toofasthost.com/api/validate');
if(!defined('GIVE_ME_CODE'))
    define('GIVE_ME_CODE', 'https://envato.toofasthost.com/api/givemecode');
?>
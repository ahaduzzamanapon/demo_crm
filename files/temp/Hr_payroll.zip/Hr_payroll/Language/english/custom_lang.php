<?php //copy from default_lang.php file and update

$lang["hr_payroll_example"] = "Example";

return $lang;